package ru.sellshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class SellShop extends JavaPlugin {
    private ShopManager shop;
    private StatsManager stats;
    private SaleLogger sales;
    private CurrencyManager currencies;
    private SellService service;
    private SellGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "shop.yml").exists()) saveResource("shop.yml", false);

        currencies = new CurrencyManager(this);
        shop = new ShopManager(this);
        shop.load();
        stats = new StatsManager(this);
        stats.load();
        sales = new SaleLogger(this);
        service = new SellService(this);
        gui = new SellGUI(this);

        getServer().getPluginManager().registerEvents(gui, this);

        getCommand("sell").setExecutor(new SellCommand(this));
        AdminCommand admin = new AdminCommand(this);
        getCommand("selladmin").setExecutor(admin);
        getCommand("selladmin").setTabCompleter(admin);

        // зберігаємо лічильник раз на 30 секунд (якщо були зміни)
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> stats.saveIfDirty(), 600L, 600L);

        // попередження, якщо немає економіки (перевіряємо після завантаження всіх плагінів)
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (Bukkit.getServicesManager().getRegistration(Economy.class) == null) {
                getLogger().warning("Vault знайдено, але плагін економіки (EssentialsX, CMI тощо) не підключено — продаж за vault не працюватиме!");
            }
        }, 100L);

        getLogger().info("SellShop увімкнено. Розділів: " + shop.categories().size());
    }

    @Override
    public void onDisable() {
        if (stats != null) stats.saveIfDirty();
    }

    public void reloadAll() {
        reloadConfig();
        currencies.reload();
        shop.load();
    }

    /** Повідомлення з config.yml з префіксом; пари плейсхолдер/значення: msg("sold", "{amount}", 5, ...). */
    public String msg(String key, Object... kv) {
        String s = getConfig().getString("messages." + key, "&cНемає повідомлення: " + key);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace(String.valueOf(kv[i]), String.valueOf(kv[i + 1]));
        }
        return Util.color(getConfig().getString("prefix", "") + s);
    }

    public ShopManager shop() { return shop; }
    public StatsManager stats() { return stats; }
    public SaleLogger sales() { return sales; }
    public CurrencyManager currencies() { return currencies; }
    public SellService service() { return service; }
    public SellGUI gui() { return gui; }
}
