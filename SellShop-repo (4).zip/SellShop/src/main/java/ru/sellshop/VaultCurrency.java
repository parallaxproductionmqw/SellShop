package ru.sellshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

/** Звичайні гроші через Vault. */
public class VaultCurrency implements Currency {
    private final String name;

    public VaultCurrency(String name) {
        this.name = name;
    }

    private Economy economy() {
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : rsp.getProvider();
    }

    @Override
    public boolean give(Player player, double amount) {
        Economy eco = economy();
        if (eco == null) return false;
        return eco.depositPlayer(player, amount).transactionSuccess();
    }

    @Override
    public String format(double amount) {
        return Util.num(amount) + " " + name;
    }
}
