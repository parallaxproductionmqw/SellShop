package ru.sellshop;

import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CurrencyManager {
    private final SellShop plugin;
    private final Map<String, Currency> currencies = new HashMap<>();

    public CurrencyManager(SellShop plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        currencies.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("currencies");
        String vaultName = sec == null ? "монет" : sec.getString("vault.name", "монет");
        currencies.put("vault", new VaultCurrency(vaultName));

        if (sec != null && sec.getBoolean("donate.enabled", false)) {
            currencies.put("donate", new CommandCurrency(
                    sec.getString("donate.name", "донат-монет"),
                    sec.getString("donate.command", "points give {player} {amount}")));
        }
    }

    /** null, якщо валюта не існує або вимкнена. */
    public Currency get(String id) {
        if (id == null) return null;
        return currencies.get(id.toLowerCase(Locale.ROOT));
    }

    public String format(String id, double amount) {
        Currency c = get(id);
        return c == null ? Util.num(amount) : c.format(amount);
    }
}
