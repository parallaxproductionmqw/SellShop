package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/** Донатна валюта: видача через консольну команду (PlayerPoints, власний плагін тощо). */
public class CommandCurrency implements Currency {
    private final String name;
    private final String command;

    public CommandCurrency(String name, String command) {
        this.name = name;
        this.command = command;
    }

    @Override
    public boolean give(Player player, double amount) {
        String cmd = command
                .replace("{player}", player.getName())
                .replace("{amount}", Util.num(amount));
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    @Override
    public String format(double amount) {
        return Util.num(amount) + " " + name;
    }
}
