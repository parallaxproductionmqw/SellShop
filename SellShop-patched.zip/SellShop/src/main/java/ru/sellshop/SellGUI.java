package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SellGUI implements Listener {
    private static final int PER_PAGE = 45;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_BACK = 49;
    private static final int SLOT_NEXT = 53;

    private final SellShop plugin;

    public SellGUI(SellShop plugin) {
        this.plugin = plugin;
    }

    /** Маркер наших меню. category == null — головне меню. */
    public static class Holder implements InventoryHolder {
        public final String category;
        public final int page;
        public final Map<Integer, String> slotToCategory = new HashMap<>();
        private Inventory inventory;

        public Holder(String category, int page) {
            this.category = category;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        void setInventory(Inventory inv) {
            this.inventory = inv;
        }
    }

    // ───────────────────────── відкриття меню ─────────────────────────

    public void openMain(Player p) {
        FileConfiguration cfg = plugin.getConfig();
        int rows = Math.max(1, Math.min(6, cfg.getInt("gui.main-rows", 3)));
        int size = rows * 9;

        Holder holder = new Holder(null, 0);
        Inventory inv = Bukkit.createInventory(holder, size, Util.color(cfg.getString("gui.main-title", "&8Скупник")));
        holder.setInventory(inv);

        if (cfg.getBoolean("gui.filler", true)) {
            ItemStack pane = pane();
            for (int i = 0; i < size; i++) inv.setItem(i, pane);
        }

        Set<Integer> used = new HashSet<>();
        List<Category> auto = new ArrayList<>();
        for (Category c : plugin.shop().categories()) {
            if (c.slot >= 0 && c.slot < size && !used.contains(c.slot)) {
                put(inv, holder, c.slot, c);
                used.add(c.slot);
            } else {
                auto.add(c);
            }
        }
        int next = 0;
        for (Category c : auto) {
            while (next < size && used.contains(next)) next++;
            if (next >= size) break;
            put(inv, holder, next, c);
            used.add(next);
        }

        p.openInventory(inv);
    }

    private void put(Inventory inv, Holder holder, int slot, Category c) {
        ItemStack it = new ItemStack(c.icon);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(c.title));
        List<String> lore = new ArrayList<>();
        lore.add(Util.color("&7Предметів: &f" + c.items.size()));
        lore.add("");
        lore.add(Util.color("&eНатисніть, щоб відкрити"));
        meta.setLore(lore);
        it.setItemMeta(meta);
        inv.setItem(slot, it);
        holder.slotToCategory.put(slot, c.id);
    }

    public void openCategory(Player p, Category c, int page) {
        int total = c.items.size();
        int pages = Math.max(1, (int) Math.ceil(total / (double) PER_PAGE));
        page = Math.max(0, Math.min(page, pages - 1));

        Holder holder = new Holder(c.id, page);
        String title = Util.color(c.title) + (pages > 1 ? Util.color(" &8(" + (page + 1) + "/" + pages + ")") : "");
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        ItemStack pane = pane();
        for (int i = PER_PAGE; i < 54; i++) inv.setItem(i, pane);

        refresh(p, inv, c, page);

        if (page > 0) inv.setItem(SLOT_PREV, named(Material.ARROW, "&e← Попередня сторінка"));
        if (page < pages - 1) inv.setItem(SLOT_NEXT, named(Material.ARROW, "&eНаступна сторінка →"));
        inv.setItem(SLOT_BACK, named(Material.BARRIER, "&cНазад до розділів"));

        p.openInventory(inv);
    }

    /** Перемальовує предмети (щоб оновити кількість в інвентарі в описі). */
    private void refresh(Player p, Inventory inv, Category c, int page) {
        List<Map.Entry<Material, Double>> list = new ArrayList<>(c.items.entrySet());
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= list.size()) {
                inv.setItem(i, null);
                continue;
            }
            Map.Entry<Material, Double> e = list.get(idx);
            inv.setItem(i, shopItem(p, c, e.getKey(), e.getValue()));
        }
    }

    private ItemStack shopItem(Player p, Category c, Material m, double price) {
        int stack = m.getMaxStackSize();
        boolean full = plugin.getConfig().getBoolean("gui.show-full-stack", true);
        ItemStack it = new ItemStack(m, full ? stack : 1);
        ItemMeta meta = it.getItemMeta();
        int have = plugin.service().count(p, m);
        int fullStacks = have / stack;
        double stackPrice = Util.round2(price);
        String id = c.currency;

        List<String> lore = new ArrayList<>();
        lore.add(Util.color("&7Ціна за стак (" + stack + " шт.): &a" + plugin.currencies().format(id, stackPrice)));
        lore.add("");
        lore.add(Util.color("&7У вашому інвентарі: &f" + have + " шт. &8(повних стаків: " + fullStacks + ")"));
        lore.add(Util.color("&7Виручка за все: &a" + plugin.currencies().format(id, Util.round2(stackPrice * fullStacks))));
        lore.add("");
        lore.add(Util.color("&eЛКМ &7— Продати стак"));
        lore.add(Util.color("&eShift + ЛКМ &7— Продати все з інвентарю"));
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack pane() {
        return named(Material.GRAY_STAINED_GLASS_PANE, " ");
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(name));
        it.setItemMeta(meta);
        return it;
    }

    // ───────────────────────── події ─────────────────────────

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        ClickType type = e.getClick();
        if (!type.isLeftClick() && !type.isRightClick()) return;

        int slot = e.getSlot();

        // головне меню
        if (holder.category == null) {
            String cid = holder.slotToCategory.get(slot);
            if (cid == null) return;
            Category c = plugin.shop().get(cid);
            if (c == null) return;
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
            openCategory(p, c, 0);
            return;
        }

        // меню розділу
        Category c = plugin.shop().get(holder.category);
        if (c == null) {
            p.closeInventory();
            return;
        }
        int pages = Math.max(1, (int) Math.ceil(c.items.size() / (double) PER_PAGE));

        if (slot == SLOT_BACK) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
            openMain(p);
            return;
        }
        if (slot == SLOT_PREV && holder.page > 0) {
            openCategory(p, c, holder.page - 1);
            return;
        }
        if (slot == SLOT_NEXT && holder.page < pages - 1) {
            openCategory(p, c, holder.page + 1);
            return;
        }
        if (slot >= PER_PAGE) return;

        List<Map.Entry<Material, Double>> list = new ArrayList<>(c.items.entrySet());
        int idx = holder.page * PER_PAGE + slot;
        if (idx >= list.size()) return;

        Material m = list.get(idx).getKey();
        plugin.service().sell(p, c, m, e.isShiftClick());
        refresh(p, e.getView().getTopInventory(), c, holder.page);
    }
}
