# SellShop 1.3.2

## What's new since 1.3.1

* **Fixed: confirmation menu.** The "Sell everything" confirmation is now a single-chest interface with three buttons: **Yes** (green), **No** (red) and a chest in the center that lists what you are about to sell (item, amount and earnings, biggest first), the total pieces and the overall total.
* **Fixed: preview on the main button.** The "Sell everything" chest in the main menu now shows a short list of the items that will be sold plus the total.
* **Fixed: return to categories.** **Yes** sells everything and returns you to the categories menu. **No** just returns you to the categories menu without selling anything.

## Upgrade notes

* Replace the jar and restart. Do not delete `config.yml`, `shop.yml` or the `lang` folder.
* Your existing settings are kept, including a custom `gui.sell-all-slot` and `gui.sell-all-icon`. The icon and slot defaults only apply to new installs.
* A new text key (`confirm.list-line`) is added to `lang/uk.yml` and `lang/en.yml` automatically; your edited texts are kept and `.bak` backups are created.
* No breaking changes.
