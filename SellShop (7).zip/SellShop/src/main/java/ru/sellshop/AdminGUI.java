package ru.sellshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Адмін-панель (/sa): усе, що раніше робилось командами, тепер кнопками.
 * Де потрібно ввести число або назву — панель закривається і показує в чаті клікабельний рядок,
 * який підставляє готову команду (лишається дописати значення).
 */
public class AdminGUI implements Listener {
    private static final int PER_PAGE = 45;

    private enum Screen { MAIN, CATEGORIES, CATEGORY, ITEM, LANGUAGE, STATS, HELP }

    public static class Holder implements InventoryHolder {
        final Screen screen;
        final String category;
        final Material material;
        final int page;
        final Map<Integer, String> keys = new HashMap<>();
        final Map<Integer, Material> mats = new HashMap<>();
        private Inventory inventory;

        Holder(Screen screen, String category, Material material, int page) {
            this.screen = screen;
            this.category = category;
            this.material = material;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final SellShop plugin;

    public AdminGUI(SellShop plugin) {
        this.plugin = plugin;
    }

    // ───────────────────────── помічники ─────────────────────────

    private ItemStack icon(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        if (lore != null && !lore.isEmpty()) meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack pane() {
        return icon(Material.GRAY_STAINED_GLASS_PANE, " ", null);
    }

    /** Текст із \n розбивається на рядки опису. */
    private List<String> lines(String key, Object... kv) {
        return new ArrayList<>(Arrays.asList(plugin.lang().text(key, kv).split("\n", -1)));
    }

    private String text(String key, Object... kv) {
        return plugin.lang().text(key, kv);
    }

    private Inventory create(Holder h, int size, String title) {
        Inventory inv = Bukkit.createInventory(h, size, title);
        h.inventory = inv;
        ItemStack pane = pane();
        for (int i = 0; i < size; i++) inv.setItem(i, pane);
        return inv;
    }

    private void clearRow(Inventory inv, int from, int to) {
        for (int i = from; i < to; i++) inv.setItem(i, null);
    }

    private static int pagesFor(int size) {
        return Math.max(1, (int) Math.ceil(size / (double) PER_PAGE));
    }

    static String languageName(String code) {
        return switch (code) {
            case "uk" -> "Українська";
            case "en" -> "English";
            case "ru" -> "Русский";
            default -> code;
        };
    }

    /** Закриває меню і показує в чаті рядок, на який можна натиснути, щоб підставити команду. */
    private void suggest(Player p, String command, String hintKey) {
        p.closeInventory();
        Component link = LegacyComponentSerializer.legacySection()
                .deserialize(plugin.msg("panel-suggest", "{command}", command))
                .clickEvent(ClickEvent.suggestCommand(command))
                .hoverEvent(HoverEvent.showText(Component.text(command)));
        p.sendMessage(link);
        p.sendMessage(plugin.msg(hintKey));
    }

    private void suggestPut(Player p, Category c, Material m) {
        suggest(p, "/sa put " + c.id + " " + m.name() + " " + m.getMaxStackSize() + " ", "panel-hint-put");
    }

    // ───────────────────────── екрани ─────────────────────────

    public void openMain(Player p) {
        Holder h = new Holder(Screen.MAIN, null, null, 0);
        Inventory inv = create(h, 27, text("panel.main.title"));

        inv.setItem(4, icon(Material.KNOWLEDGE_BOOK, text("panel.main.help"), lines("panel.main.help-lore")));
        inv.setItem(10, icon(Material.CHEST, text("panel.main.categories"),
                lines("panel.main.categories-lore", "{count}", plugin.shop().categories().size())));
        inv.setItem(12, icon(Material.WRITABLE_BOOK, text("panel.main.language"),
                lines("panel.main.language-lore", "{language}", languageName(plugin.lang().code()))));
        inv.setItem(14, icon(Material.BARREL, text("panel.main.stats"),
                lines("panel.main.stats-lore", "{kinds}", plugin.stats().sorted().size())));
        inv.setItem(16, icon(Material.COMPARATOR, text("panel.main.reload"), lines("panel.main.reload-lore")));
        inv.setItem(22, icon(Material.PAPER, text("panel.main.commands"), lines("panel.main.commands-lore")));
        inv.setItem(26, icon(Material.BARRIER, text("panel.close"), null));
        p.openInventory(inv);
    }

    public void openCategories(Player p) {
        Holder h = new Holder(Screen.CATEGORIES, null, null, 0);
        Inventory inv = create(h, 54, text("panel.categories.title"));
        clearRow(inv, 0, PER_PAGE);

        int slot = 0;
        for (Category c : plugin.shop().categories()) {
            if (slot >= PER_PAGE) break;
            inv.setItem(slot, icon(c.icon, Util.color(c.title),
                    lines("panel.categories.item-lore", "{id}", c.id, "{count}", c.items.size(),
                            "{currency}", c.currency)));
            h.keys.put(slot, c.id);
            slot++;
        }
        inv.setItem(49, icon(Material.EMERALD, text("panel.categories.add"), lines("panel.categories.add-lore")));
        inv.setItem(53, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    public void openCategory(Player p, String id, int page) {
        Category c = plugin.shop().get(id);
        if (c == null) {
            openCategories(p);
            return;
        }
        List<Map.Entry<Material, Double>> entries = new ArrayList<>(c.items.entrySet());
        int pages = pagesFor(entries.size());
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(Screen.CATEGORY, c.id, null, pg);
        Inventory inv = create(h, 54, text("panel.category.title", "{category}", c.id));
        clearRow(inv, 0, PER_PAGE);

        int from = pg * PER_PAGE;
        for (int i = from; i < Math.min(entries.size(), from + PER_PAGE); i++) {
            Material m = entries.get(i).getKey();
            int slot = i - from;
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(priceLine(c, m));
            lore.add("");
            lore.add(text("panel.category.item-click"));
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(slot, it);
            h.mats.put(slot, m);
        }

        if (pg > 0) inv.setItem(45, icon(Material.ARROW, text("menu.prev"), null));
        inv.setItem(46, icon(Material.ARROW, text("panel.back"), null));
        inv.setItem(48, icon(Material.LIME_DYE, text("panel.category.add"), lines("panel.category.add-lore")));
        inv.setItem(50, icon(Material.TNT, text("panel.category.remove"), lines("panel.category.remove-lore")));
        if (pg < pages - 1) inv.setItem(53, icon(Material.ARROW, text("menu.next"), null));
        p.openInventory(inv);
    }

    private String priceLine(Category c, Material m) {
        String price = plugin.currencies().format(c.currency, c.items.get(m));
        return c.isPiece(m)
                ? text("item.price-piece", "{amount}", c.unit(m), "{price}", price)
                : text("item.price-stack", "{amount}", m.getMaxStackSize(), "{price}", price);
    }

    public void openItem(Player p, String categoryId, Material m) {
        Category c = plugin.shop().get(categoryId);
        if (c == null) {
            openCategories(p);
            return;
        }
        if (!c.items.containsKey(m)) {
            openCategory(p, c.id, 0);
            return;
        }
        boolean piece = c.isPiece(m);
        int unit = c.unit(m);
        String price = plugin.currencies().format(c.currency, c.items.get(m));

        Holder h = new Holder(Screen.ITEM, c.id, m, 0);
        Inventory inv = create(h, 27, text("panel.item.title", "{item}", Util.name(m)));

        List<String> infoLore = new ArrayList<>();
        infoLore.add(priceLine(c, m));
        inv.setItem(4, icon(m, Util.color("&f" + Util.name(m)), infoLore));

        inv.setItem(10, icon(Material.GOLD_INGOT, text("panel.item.price"),
                lines("panel.item.price-lore", "{price}", price)));
        if (piece) {
            inv.setItem(12, icon(Material.COMPARATOR, text("panel.item.mode-piece", "{amount}", unit),
                    lines("panel.item.mode-piece-lore", "{amount}", unit)));
            inv.setItem(14, icon(Material.REPEATER, text("panel.item.amount"),
                    lines("panel.item.amount-lore", "{amount}", unit)));
        } else {
            inv.setItem(12, icon(Material.COMPARATOR, text("panel.item.mode-stack"),
                    lines("panel.item.mode-stack-lore")));
        }
        inv.setItem(16, icon(Material.TNT, text("panel.item.remove"), lines("panel.item.remove-lore")));
        inv.setItem(22, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    public void openLanguage(Player p) {
        Holder h = new Holder(Screen.LANGUAGE, null, null, 0);
        Inventory inv = create(h, 27, text("panel.language.title"));
        inv.setItem(4, icon(Material.BOOK, text("panel.language.info"), lines("panel.language.info-lore")));

        File dir = new File(plugin.getDataFolder(), "lang");
        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        List<String> codes = new ArrayList<>();
        if (files != null) {
            for (File f : files) {
                String n = f.getName();
                codes.add(n.substring(0, n.length() - 4));
            }
        }
        Collections.sort(codes);

        String current = plugin.lang().code();
        int slot = 10;
        for (String code : codes) {
            if (slot > 16) break;
            boolean active = code.equals(current);
            ItemStack it = icon(Material.PAPER, Util.color("&f&l" + languageName(code)),
                    new ArrayList<>(List.of(active ? text("panel.language.current") : text("panel.language.click"))));
            if (active) {
                ItemMeta meta = it.getItemMeta();
                meta.setEnchantmentGlintOverride(true);
                it.setItemMeta(meta);
            }
            inv.setItem(slot, it);
            h.keys.put(slot, code);
            slot++;
        }
        inv.setItem(26, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    /** Міні-довідник для новачків: чотири кроки від порожнього магазину до першої ціни. */
    public void openHelp(Player p) {
        Holder h = new Holder(Screen.HELP, null, null, 0);
        Inventory inv = create(h, 27, text("panel.help.title"));
        inv.setItem(10, icon(Material.CHEST, text("panel.help.step1"), lines("panel.help.step1-lore")));
        inv.setItem(12, icon(Material.LIME_DYE, text("panel.help.step2"), lines("panel.help.step2-lore")));
        inv.setItem(14, icon(Material.GOLD_INGOT, text("panel.help.step3"), lines("panel.help.step3-lore")));
        inv.setItem(16, icon(Material.COMPARATOR, text("panel.help.step4"), lines("panel.help.step4-lore")));
        inv.setItem(22, icon(Material.PAPER, text("panel.main.commands"), lines("panel.main.commands-lore")));
        inv.setItem(26, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    private void sendCommandList(Player p) {
        p.closeInventory();
        for (String key : List.of("header", "panel", "add", "put", "price", "unit", "remove",
                "addcategory", "removecategory", "stats", "take", "reload")) {
            p.sendMessage(plugin.lang().text("admin.help." + key));
        }
    }

    public void openStats(Player p, int page) {
        List<Map.Entry<Material, Long>> list = plugin.stats().sorted();
        int pages = pagesFor(list.size());
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(Screen.STATS, null, null, pg);
        Inventory inv = create(h, 54, text("panel.stats.title"));
        clearRow(inv, 0, PER_PAGE);

        int from = pg * PER_PAGE;
        for (int i = from; i < Math.min(list.size(), from + PER_PAGE); i++) {
            Map.Entry<Material, Long> e = list.get(i);
            int slot = i - from;
            inv.setItem(slot, icon(e.getKey(), Util.color("&f" + Util.name(e.getKey())),
                    lines("panel.stats.item-lore", "{amount}", e.getValue(),
                            "{stack}", e.getKey().getMaxStackSize())));
            h.mats.put(slot, e.getKey());
        }
        if (pg > 0) inv.setItem(45, icon(Material.ARROW, text("menu.prev"), null));
        inv.setItem(49, icon(Material.ARROW, text("panel.back"), null));
        if (pg < pages - 1) inv.setItem(53, icon(Material.ARROW, text("menu.next"), null));
        p.openInventory(inv);
    }

    // ───────────────────────── події ─────────────────────────

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!p.hasPermission("sellshop.admin")) {
            p.closeInventory();
            return;
        }
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;

        // клік по власному інвентарю гравця в розділі = додати цей предмет у розділ
        if (clicked != e.getView().getTopInventory()) {
            if (h.screen == Screen.CATEGORY) {
                ItemStack cur = e.getCurrentItem();
                Category c = plugin.shop().get(h.category);
                if (c != null && cur != null && !cur.getType().isAir()) suggestPut(p, c, cur.getType());
            }
            return;
        }

        int slot = e.getSlot();
        ItemStack item = e.getCurrentItem();
        if (item == null || item.getType() == Material.GRAY_STAINED_GLASS_PANE) return;
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1f);

        switch (h.screen) {
            case MAIN -> clickMain(p, slot);
            case CATEGORIES -> clickCategories(p, h, slot);
            case CATEGORY -> clickCategory(p, h, slot, e.isShiftClick());
            case ITEM -> clickItem(p, h, slot, e.isShiftClick());
            case LANGUAGE -> clickLanguage(p, h, slot);
            case STATS -> clickStats(p, h, slot, e.isShiftClick());
            case HELP -> clickHelp(p, slot);
        }
    }

    private void clickMain(Player p, int slot) {
        switch (slot) {
            case 4 -> openHelp(p);
            case 10 -> openCategories(p);
            case 12 -> openLanguage(p);
            case 14 -> openStats(p, 0);
            case 16 -> {
                plugin.reloadAll();
                p.sendMessage(plugin.msg("reloaded"));
                openMain(p);
            }
            case 22 -> sendCommandList(p);
            case 26 -> p.closeInventory();
            default -> { }
        }
    }

    private void clickHelp(Player p, int slot) {
        if (slot == 22) sendCommandList(p);
        else if (slot == 26) openMain(p);
    }

    private void clickCategories(Player p, Holder h, int slot) {
        if (slot == 53) {
            openMain(p);
        } else if (slot == 49) {
            suggest(p, "/sa addcategory ", "panel-hint-addcategory");
        } else if (h.keys.containsKey(slot)) {
            openCategory(p, h.keys.get(slot), 0);
        }
    }

    private void clickCategory(Player p, Holder h, int slot, boolean shift) {
        Category c = plugin.shop().get(h.category);
        if (c == null) {
            openCategories(p);
            return;
        }
        if (h.mats.containsKey(slot)) {
            openItem(p, c.id, h.mats.get(slot));
            return;
        }
        switch (slot) {
            case 45 -> openCategory(p, c.id, h.page - 1);
            case 53 -> openCategory(p, c.id, h.page + 1);
            case 46 -> openCategories(p);
            case 48 -> {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (!hand.getType().isAir()) suggestPut(p, c, hand.getType());
            }
            case 50 -> {
                if (!shift) {
                    p.sendMessage(plugin.msg("panel-shift"));
                    return;
                }
                plugin.shop().removeCategory(c.id);
                p.sendMessage(plugin.msg("category-removed", "{category}", c.id));
                openCategories(p);
            }
            default -> { }
        }
    }

    private void clickItem(Player p, Holder h, int slot, boolean shift) {
        Category c = plugin.shop().get(h.category);
        Material m = h.material;
        if (c == null || m == null || !c.items.containsKey(m)) {
            openCategories(p);
            return;
        }
        String base = "/sa ";
        switch (slot) {
            case 10 -> suggest(p, base + "price " + c.id + " " + m.name() + " ", "panel-hint-price");
            case 12 -> {
                if (c.isPiece(m)) {
                    plugin.shop().setUnit(c, m, null);
                    p.sendMessage(plugin.msg("unit-stack", "{item}", Util.name(m), "{category}", c.id,
                            "{stack}", m.getMaxStackSize()));
                    openItem(p, c.id, m);
                } else {
                    suggest(p, base + "unit " + c.id + " " + m.name() + " ", "panel-hint-unit");
                }
            }
            case 14 -> {
                if (c.isPiece(m)) suggest(p, base + "unit " + c.id + " " + m.name() + " ", "panel-hint-unit");
            }
            case 16 -> {
                if (!shift) {
                    p.sendMessage(plugin.msg("panel-shift"));
                    return;
                }
                plugin.shop().removeItem(c, m);
                p.sendMessage(plugin.msg("item-removed", "{item}", Util.name(m), "{category}", c.id));
                openCategory(p, c.id, 0);
            }
            case 22 -> openCategory(p, c.id, 0);
            default -> { }
        }
    }

    private void clickLanguage(Player p, Holder h, int slot) {
        if (slot == 26) {
            openMain(p);
            return;
        }
        String code = h.keys.get(slot);
        if (code == null || code.equals(plugin.lang().code())) return;

        plugin.getConfig().set("language", code);
        plugin.saveConfig();
        plugin.reloadAll();
        p.sendMessage(plugin.msg("language-changed", "{language}", languageName(code)));
        openLanguage(p);
    }

    private void clickStats(Player p, Holder h, int slot, boolean shift) {
        switch (slot) {
            case 45 -> {
                openStats(p, h.page - 1);
                return;
            }
            case 53 -> {
                openStats(p, h.page + 1);
                return;
            }
            case 49 -> {
                openMain(p);
                return;
            }
            default -> { }
        }
        Material m = h.mats.get(slot);
        if (m == null) return;

        long have = plugin.stats().get(m);
        if (have <= 0) {
            p.sendMessage(plugin.msg("take-empty", "{item}", Util.name(m)));
            openStats(p, h.page);
            return;
        }
        long want = shift ? have : Math.min(have, m.getMaxStackSize());
        long taken = plugin.stats().take(m, want);
        plugin.service().giveItems(p, m, taken);
        plugin.sales().log(String.format("TAKE %s took %dx %s from counter (left %d)",
                p.getName(), taken, m.name(), plugin.stats().get(m)));
        p.sendMessage(plugin.msg("take-ok",
                "{amount}", taken, "{item}", Util.name(m), "{left}", plugin.stats().get(m)));
        openStats(p, h.page);
    }
}
