# SellShop 1.4

## What's new since 1.3.2

* **Admin panel.** Type `/sa` and a menu opens where you manage the shop with buttons instead of commands:
  * **Categories and items:** open any category, click an item to change its price, switch between full stack and bundle selling, change the bundle size or delete it. Create and delete categories.
  * **Add items by clicking.** While a category is open, click any item in your own inventory (or hold it and press the green button) to add it.
  * **Plugin language:** choose the default language (Ukrainian, English or your own file from `lang/`). It is saved to `config.yml` and applied at once.
  * **Sold counter:** see what players have sold and take it back (left click: one stack, Shift + left click: everything).
  * **Quick start guide:** a short four-step help screen for beginners (create a category, add items, change price or mode, language and reload).
  * **Reload** and a **command list** in one click.
* **Easy value input.** Where a number or a name is needed (price, bundle size, new category), the panel shows a clickable line in chat that fills your chat box with the ready command. You only type the value and press Enter.
* **Safe deleting.** Removing an item or a category needs Shift + left click.
* **New command `/sa put <category> <item> <amount> <price>`.** Same as `/sa add`, but the item comes first. The panel uses it to fill in the command for you.
* **Hidden from regular players.** `/sa` and the panel are admin-only (`sellshop.admin`). The command does not show up in tab completion or `/help` for players, and typing it just gives the standard "Unknown command" message, so players never learn that the plugin has an admin side. The panel is only opened with `/sa`; the normal `/sell` menu is unchanged.
* `/sa` without arguments now opens the panel (from the console it still shows the command list). `/sa panel` does the same.
* New texts in Ukrainian and English.

## Upgrade notes

* Replace the jar and restart. Do not delete `config.yml`, `shop.yml` or the `lang` folder.
* All old commands (`/sa add`, `price`, `unit`, `remove`, `addcategory`, `removecategory`, `stats`, `take`, `reload`, `help`) keep working.
* New texts are added to `lang/uk.yml` and `lang/en.yml` automatically; your edited texts are kept and `.bak` backups are created.
* Changing the language in the panel changes the plugin texts only. Category names stored in `shop.yml` are not translated.
* Permission is unchanged: the panel needs `sellshop.admin` (operators by default). Players without it no longer see the command at all.
* No breaking changes.
