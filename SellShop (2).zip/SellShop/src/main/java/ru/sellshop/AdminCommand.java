package ru.sellshop;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * /selladmin (/sa):
 *   add <розділ> <кількість> <ціна> [предмет] — додати предмет: ціна діє за вказану кількість (за замовчуванням предмет з руки)
 *   remove <розділ> <предмет>          — прибрати предмет з розділу
 *   price <розділ> <предмет> <ціна>    — змінити ціну
 *   unit <розділ> <предмет> <кількість|stack> — продаж наборами по N штук або повними стаками
 *   addcategory <id> <іконка> [назва] / removecategory <id>
 *   stats [сторінка]                   — лічильник проданого
 *   take <предмет> [кількість|all]        — дістати предмети з лічильника
 *   reload
 */
public class AdminCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of(
            "add", "remove", "price", "unit", "addcategory", "removecategory", "stats", "take", "reload", "help");

    private final SellShop plugin;

    public AdminCommand(SellShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("sellshop.admin")) {
            s.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        if (a.length == 0) {
            help(s);
            return true;
        }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "add" -> add(s, a);
            case "remove" -> remove(s, a);
            case "price" -> price(s, a);
            case "unit" -> unit(s, a);
            case "addcategory" -> addCategory(s, a);
            case "removecategory" -> removeCategory(s, a);
            case "stats" -> stats(s, a);
            case "take" -> take(s, a);
            case "reload" -> {
                plugin.reloadAll();
                s.sendMessage(plugin.msg("reloaded"));
            }
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        for (String key : List.of("header", "add", "price", "unit", "remove", "addcategory",
                "removecategory", "stats", "take", "reload")) {
            s.sendMessage(plugin.lang().text("admin.help." + key));
        }
    }

    // ───────────────────────── підкоманди ─────────────────────────

    private void add(CommandSender s, String[] a) {
        if (a.length < 4) {
            s.sendMessage(plugin.lang().text("admin.usage.add"));
            return;
        }
        Category c = plugin.shop().get(a[1]);
        if (c == null) {
            s.sendMessage(plugin.msg("category-not-found", "{category}", a[1]));
            return;
        }
        int amount;
        try {
            amount = Integer.parseInt(a[2]);
        } catch (NumberFormatException ex) {
            s.sendMessage(plugin.msg("invalid-number", "{value}", a[2]));
            return;
        }
        if (amount < 1) {
            s.sendMessage(plugin.msg("invalid-number", "{value}", a[2]));
            return;
        }
        Double price = parsePrice(s, a[3]);
        if (price == null) return;

        Material m;
        if (a.length >= 5) {
            m = parseItem(s, a[4]);
        } else if (s instanceof Player p) {
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) {
                s.sendMessage(plugin.msg("hold-item"));
                return;
            }
            m = hand.getType();
        } else {
            s.sendMessage(plugin.msg("hold-item"));
            return;
        }
        if (m == null) return;

        // кількість = повний стак → звичайний режим «стак», інакше набір по N штук
        Integer unit = amount == m.getMaxStackSize() ? null : amount;
        plugin.shop().setItem(c, m, price, unit);
        s.sendMessage(plugin.msg("item-added",
                "{item}", Util.name(m), "{category}", c.id, "{amount}", amount,
                "{price}", plugin.currencies().format(c.currency, price)));
    }

    private void remove(CommandSender s, String[] a) {
        if (a.length < 3) {
            s.sendMessage(plugin.lang().text("admin.usage.remove"));
            return;
        }
        Category c = plugin.shop().get(a[1]);
        if (c == null) {
            s.sendMessage(plugin.msg("category-not-found", "{category}", a[1]));
            return;
        }
        Material m = parseItem(s, a[2]);
        if (m == null) return;

        if (plugin.shop().removeItem(c, m)) {
            s.sendMessage(plugin.msg("item-removed", "{item}", Util.name(m), "{category}", c.id));
        } else {
            s.sendMessage(plugin.msg("item-not-in-category", "{item}", Util.name(m), "{category}", c.id));
        }
    }

    private void price(CommandSender s, String[] a) {
        if (a.length < 4) {
            s.sendMessage(plugin.lang().text("admin.usage.price"));
            return;
        }
        Category c = plugin.shop().get(a[1]);
        if (c == null) {
            s.sendMessage(plugin.msg("category-not-found", "{category}", a[1]));
            return;
        }
        Material m = parseItem(s, a[2]);
        if (m == null) return;
        if (!c.items.containsKey(m)) {
            s.sendMessage(plugin.msg("item-not-in-category", "{item}", Util.name(m), "{category}", c.id));
            return;
        }
        Double price = parsePrice(s, a[3]);
        if (price == null) return;

        plugin.shop().setItem(c, m, price);
        s.sendMessage(plugin.msg("price-set",
                "{item}", Util.name(m), "{category}", c.id, "{price}", Util.num(price)));
    }

    private void unit(CommandSender s, String[] a) {
        if (a.length < 4) {
            s.sendMessage(plugin.lang().text("admin.usage.unit"));
            return;
        }
        Category c = plugin.shop().get(a[1]);
        if (c == null) {
            s.sendMessage(plugin.msg("category-not-found", "{category}", a[1]));
            return;
        }
        Material m = parseItem(s, a[2]);
        if (m == null) return;
        if (!c.items.containsKey(m)) {
            s.sendMessage(plugin.msg("item-not-in-category", "{item}", Util.name(m), "{category}", c.id));
            return;
        }
        if (a[3].equalsIgnoreCase("stack")) {
            plugin.shop().setUnit(c, m, null);
            s.sendMessage(plugin.msg("unit-stack", "{item}", Util.name(m), "{category}", c.id,
                    "{stack}", m.getMaxStackSize()));
            return;
        }
        int amount;
        try {
            amount = Integer.parseInt(a[3]);
        } catch (NumberFormatException ex) {
            s.sendMessage(plugin.msg("invalid-number", "{value}", a[3]));
            return;
        }
        if (amount < 1) {
            s.sendMessage(plugin.msg("invalid-number", "{value}", a[3]));
            return;
        }
        plugin.shop().setUnit(c, m, amount);
        s.sendMessage(plugin.msg("unit-set", "{item}", Util.name(m), "{category}", c.id, "{amount}", amount));
    }

    private void addCategory(CommandSender s, String[] a) {
        if (a.length < 3) {
            s.sendMessage(plugin.lang().text("admin.usage.addcategory"));
            return;
        }
        if (plugin.shop().get(a[1]) != null) {
            s.sendMessage(plugin.msg("category-exists", "{category}", a[1]));
            return;
        }
        Material icon = parseItem(s, a[2]);
        if (icon == null) return;

        String title = a.length >= 4
                ? String.join(" ", Arrays.copyOfRange(a, 3, a.length))
                : "&f" + a[1];
        plugin.shop().createCategory(a[1], title, icon);
        s.sendMessage(plugin.msg("category-added", "{category}", a[1].toLowerCase(Locale.ROOT)));
    }

    private void removeCategory(CommandSender s, String[] a) {
        if (a.length < 2) {
            s.sendMessage(plugin.lang().text("admin.usage.removecategory"));
            return;
        }
        if (plugin.shop().removeCategory(a[1])) {
            s.sendMessage(plugin.msg("category-removed", "{category}", a[1]));
        } else {
            s.sendMessage(plugin.msg("category-not-found", "{category}", a[1]));
        }
    }

    private void stats(CommandSender s, String[] a) {
        List<Map.Entry<Material, Long>> list = plugin.stats().sorted();
        int perPage = 10;
        int pages = Math.max(1, (int) Math.ceil(list.size() / (double) perPage));
        int page = 1;
        if (a.length >= 2) {
            try {
                page = Integer.parseInt(a[1]);
            } catch (NumberFormatException ex) {
                s.sendMessage(plugin.msg("invalid-number", "{value}", a[1]));
                return;
            }
        }
        page = Math.max(1, Math.min(page, pages));

        s.sendMessage(plugin.lang().text("admin.stats-header", "{page}", page, "{pages}", pages));
        if (list.isEmpty()) {
            s.sendMessage(plugin.lang().text("admin.stats-empty"));
            return;
        }
        int from = (page - 1) * perPage;
        for (int i = from; i < Math.min(list.size(), from + perPage); i++) {
            Map.Entry<Material, Long> e = list.get(i);
            s.sendMessage(plugin.lang().text("admin.stats-line", "{n}", i + 1,
                    "{item}", Util.name(e.getKey()), "{amount}", e.getValue()));
        }
    }

    private void take(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.msg("players-only"));
            return;
        }
        if (a.length < 2) {
            p.sendMessage(plugin.lang().text("admin.usage.take"));
            return;
        }
        Material m = parseItem(p, a[1]);
        if (m == null) return;

        long have = plugin.stats().get(m);
        if (have <= 0) {
            p.sendMessage(plugin.msg("take-empty", "{item}", Util.name(m)));
            return;
        }

        long want;
        if (a.length < 3) {
            want = m.getMaxStackSize();
        } else if (a[2].equalsIgnoreCase("all")) {
            want = have;
        } else {
            try {
                want = Long.parseLong(a[2]);
            } catch (NumberFormatException ex) {
                p.sendMessage(plugin.msg("invalid-number", "{value}", a[2]));
                return;
            }
            if (want <= 0) {
                p.sendMessage(plugin.msg("invalid-number", "{value}", a[2]));
                return;
            }
        }

        long taken = plugin.stats().take(m, want);
        plugin.service().giveItems(p, m, taken);
        plugin.sales().log(String.format("TAKE %s took %dx %s from counter (left %d)",
                p.getName(), taken, m.name(), plugin.stats().get(m)));
        p.sendMessage(plugin.msg("take-ok",
                "{amount}", taken, "{item}", Util.name(m), "{left}", plugin.stats().get(m)));
    }

    // ───────────────────────── парсинг ─────────────────────────

    private Double parsePrice(CommandSender s, String raw) {
        try {
            double d = Double.parseDouble(raw.replace(',', '.'));
            if (d < 0 || Double.isNaN(d) || Double.isInfinite(d)) throw new NumberFormatException();
            return d;
        } catch (NumberFormatException ex) {
            s.sendMessage(plugin.msg("invalid-number", "{value}", raw));
            return null;
        }
    }

    private Material parseItem(CommandSender s, String raw) {
        Material m = Material.matchMaterial(raw);
        if (m == null || !m.isItem() || m.isAir()) {
            s.sendMessage(plugin.msg("invalid-item", "{item}", raw));
            return null;
        }
        return m;
    }

    // ───────────────────────── автодоповнення ─────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        if (!s.hasPermission("sellshop.admin")) return List.of();

        if (a.length == 1) return filter(SUB, a[0]);

        String sub = a[0].toLowerCase(Locale.ROOT);
        List<String> categories = plugin.shop().categories().stream().map(c -> c.id).collect(Collectors.toList());

        if (a.length == 2) {
            switch (sub) {
                case "add", "remove", "price", "unit", "removecategory":
                    return filter(categories, a[1]);
                case "take":
                    return filter(stockedMaterials(), a[1]);
                default:
                    return List.of();
            }
        }
        if (a.length == 3) {
            switch (sub) {
                case "remove", "price", "unit": {
                    Category c = plugin.shop().get(a[1]);
                    if (c == null) return List.of();
                    return filter(c.items.keySet().stream().map(Material::name).collect(Collectors.toList()), a[2]);
                }
                case "addcategory":
                    return materialNames(a[2]);
                case "add":
                    return filter(List.of("1", "8", "16", "24", "64"), a[2]);
                case "take":
                    return filter(List.of("all", "64", "16", "1"), a[2]);
                default:
                    return List.of();
            }
        }
        if (a.length == 4 && sub.equals("unit")) return filter(List.of("stack", "1", "8", "16", "64"), a[3]);
        if (a.length == 5 && sub.equals("add")) return materialNames(a[4]);
        return List.of();
    }

    private List<String> stockedMaterials() {
        List<String> out = new ArrayList<>();
        for (Map.Entry<Material, Long> e : plugin.stats().sorted()) out.add(e.getKey().name());
        return out;
    }

    private List<String> materialNames(String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return Arrays.stream(Material.values())
                .filter(m -> m.isItem() && !m.isAir() && !m.name().startsWith("LEGACY_"))
                .map(Material::name)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(p))
                .limit(50)
                .collect(Collectors.toList());
    }

    private List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return options.stream()
                .filter(o -> o.toLowerCase(Locale.ROOT).startsWith(p))
                .collect(Collectors.toList());
    }
}
