package ru.sellshop;

import org.bukkit.Material;

import java.util.LinkedHashMap;

public class Category {
    public final String id;
    public String title;
    public Material icon;
    public int slot;
    public String currency;
    /** Предмет -> ціна за 1 повний стак (продається лише повними стаками). */
    public final LinkedHashMap<Material, Double> items = new LinkedHashMap<>();
    /**
     * Предмет -> кількість штук, за яку діє ціна (режим "поштучно").
     * Якщо предмета тут немає — він продається повними стаками (режим "стак").
     */
    public final LinkedHashMap<Material, Integer> units = new LinkedHashMap<>();

    /** Скільки штук продається за одну ціну: заданий набір або повний стак предмета. */
    public int unit(Material m) {
        Integer u = units.get(m);
        return u != null && u > 0 ? u : m.getMaxStackSize();
    }

    /** true — предмет продається наборами по N штук, false — повними стаками. */
    public boolean isPiece(Material m) {
        return units.containsKey(m);
    }

    public Category(String id, String title, Material icon, int slot, String currency) {
        this.id = id;
        this.title = title;
        this.icon = icon;
        this.slot = slot;
        this.currency = currency;
    }
}
