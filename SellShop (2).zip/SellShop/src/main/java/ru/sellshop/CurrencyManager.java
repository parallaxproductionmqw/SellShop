package ru.sellshop;

import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CurrencyManager {
    private final SellShop plugin;
    private final Map<String, Currency> currencies = new HashMap<>();

    public CurrencyManager(SellShop plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        currencies.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("currencies");
        String format = plugin.lang().raw("currency.format");
        String vaultName = sec == null ? "" : sec.getString("vault.name", "");
        if (vaultName == null || vaultName.isBlank()) vaultName = plugin.lang().raw("currency.vault-name");
        currencies.put("vault", new VaultCurrency(vaultName, format));

        if (sec != null && sec.getBoolean("donate.enabled", false)) {
            String donateName = sec.getString("donate.name", "");
            if (donateName == null || donateName.isBlank()) donateName = plugin.lang().raw("currency.donate-name");
            currencies.put("donate", new CommandCurrency(
                    donateName,
                    sec.getString("donate.command", "points give {player} {amount}"),
                    format));
        }
    }

    /** null, якщо валюта не існує або вимкнена. */
    public Currency get(String id) {
        if (id == null) return null;
        return currencies.get(id.toLowerCase(Locale.ROOT));
    }

    public String format(String id, double amount) {
        Currency c = get(id);
        return c == null ? Util.num(amount) : c.format(amount);
    }
}
