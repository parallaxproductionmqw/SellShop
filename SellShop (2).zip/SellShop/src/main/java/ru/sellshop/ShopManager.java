package ru.sellshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Зберігає розділи та ціни, читає/пише shop.yml. */
public class ShopManager {
    private final SellShop plugin;
    private final File file;
    private final Map<String, Category> categories = new LinkedHashMap<>();

    public ShopManager(SellShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
    }

    public synchronized void load() {
        categories.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("categories");
        if (root == null) return;

        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;

            Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
            if (icon == null || !icon.isItem()) icon = Material.CHEST;

            Category c = new Category(
                    id.toLowerCase(Locale.ROOT),
                    s.getString("title", "&f" + id),
                    icon,
                    s.getInt("slot", -1),
                    s.getString("currency", "vault"));

            ConfigurationSection items = s.getConfigurationSection("items");
            if (items != null) {
                for (String key : items.getKeys(false)) {
                    Material m = Material.matchMaterial(key);
                    if (m == null || !m.isItem() || m.isAir()) {
                        plugin.getLogger().warning(plugin.lang().raw("log.unknown-item", "{item}", key, "{category}", id));
                        continue;
                    }
                    if (items.isConfigurationSection(key)) {
                        // новий формат: mode / amount / price
                        ConfigurationSection is = items.getConfigurationSection(key);
                        c.items.put(m, is.getDouble("price", 0.0));
                        String mode = is.getString("mode", "stack");
                        if (mode.equalsIgnoreCase("piece")) {
                            int amount = is.getInt("amount", 1);
                            if (amount < 1) amount = 1;
                            c.units.put(m, amount);
                        }
                    } else {
                        // старий формат: просто число = ціна за повний стак
                        c.items.put(m, items.getDouble(key));
                    }
                }
            }
            categories.put(c.id, c);
        }
    }

    public synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Category c : categories.values()) {
            String base = "categories." + c.id + ".";
            y.set(base + "title", c.title);
            y.set(base + "icon", c.icon.name());
            y.set(base + "slot", c.slot);
            y.set(base + "currency", c.currency);
            for (Map.Entry<Material, Double> e : c.items.entrySet()) {
                String ib = base + "items." + e.getKey().name();
                Integer unit = c.units.get(e.getKey());
                if (unit != null) {
                    y.set(ib + ".mode", "piece");
                    y.set(ib + ".amount", unit);
                    y.set(ib + ".price", e.getValue());
                } else {
                    y.set(ib, e.getValue());
                }
            }
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe(plugin.lang().raw("log.shop-save-failed", "{error}", ex.getMessage()));
        }
    }

    public synchronized Collection<Category> categories() {
        return categories.values();
    }

    public synchronized Category get(String id) {
        return id == null ? null : categories.get(id.toLowerCase(Locale.ROOT));
    }

    public synchronized Category createCategory(String id, String title, Material icon) {
        Category c = new Category(id.toLowerCase(Locale.ROOT), title, icon, -1, "vault");
        categories.put(c.id, c);
        save();
        return c;
    }

    public synchronized boolean removeCategory(String id) {
        boolean removed = categories.remove(id.toLowerCase(Locale.ROOT)) != null;
        if (removed) save();
        return removed;
    }

    /** Додає/оновлює предмет. Режим (стак/поштучно) лишається як був. */
    public synchronized void setItem(Category c, Material m, double price) {
        c.items.put(m, price);
        save();
    }

    /** Додає предмет разом із кількістю: unit == null — продаж повним стаком, інакше набори по unit штук. */
    public synchronized void setItem(Category c, Material m, double price, Integer unit) {
        c.items.put(m, price);
        if (unit == null) c.units.remove(m);
        else c.units.put(m, unit);
        save();
    }

    /** Змінює режим продажу: unit == null — повні стаки, інакше набори по unit штук. */
    public synchronized void setUnit(Category c, Material m, Integer unit) {
        if (unit == null) c.units.remove(m);
        else c.units.put(m, unit);
        save();
    }

    public synchronized boolean removeItem(Category c, Material m) {
        c.units.remove(m);
        boolean removed = c.items.remove(m) != null;
        if (removed) save();
        return removed;
    }
}
