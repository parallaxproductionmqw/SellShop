package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/** Донатна валюта: видача через консольну команду (PlayerPoints, власний плагін тощо). */
public class CommandCurrency implements Currency {
    private final String name;
    private final String command;
    private final String format;

    public CommandCurrency(String name, String command, String format) {
        this.name = name;
        this.command = command;
        this.format = format;
    }

    @Override
    public boolean give(Player player, double amount) {
        String cmd = command
                .replace("{player}", player.getName())
                .replace("{amount}", Util.num(amount));
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String format(double amount) {
        return format.replace("{name}", name).replace("{amount}", Util.num(amount));
    }
}
