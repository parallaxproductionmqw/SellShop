package ru.sellshop;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Локалізація: тексти беруться з plugins/SellShop/lang/&lt;код&gt;.yml. Вбудовані мови — uk та en,
 * можна додати власний файл і вказати його код у config.yml (language).
 */
public class Lang {
    private static final List<String> BUNDLED = List.of("uk", "en");

    private final SellShop plugin;
    private YamlConfiguration lang;
    private String code = "uk";

    public Lang(SellShop plugin) {
        this.plugin = plugin;
        reload();
    }

    public String code() {
        return code;
    }

    public void reload() {
        File dir = new File(plugin.getDataFolder(), "lang");
        if (!dir.exists() && !dir.mkdirs()) {
            plugin.getLogger().warning("Cannot create folder " + dir.getPath());
        }

        boolean firstUk = !new File(dir, "uk.yml").exists();
        for (String c : BUNDLED) {
            File f = new File(dir, c + ".yml");
            if (!f.exists()) plugin.saveResource("lang/" + c + ".yml", false);
        }
        if (firstUk) migrateLegacy(new File(dir, "uk.yml"));
        for (String c : BUNDLED) mergeMissing(new File(dir, c + ".yml"), c);

        String wanted = plugin.getConfig().getString("language", "uk").trim().toLowerCase(Locale.ROOT);
        File file = new File(dir, wanted + ".yml");
        if (!file.exists()) {
            plugin.getLogger().warning("Language file lang/" + wanted + ".yml not found, using uk");
            wanted = "uk";
            file = new File(dir, "uk.yml");
        }
        code = wanted;

        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        YamlConfiguration def = loadJar(BUNDLED.contains(code) ? code : "en");
        if (def != null) y.setDefaults(def);
        lang = y;
    }

    private YamlConfiguration loadJar(String c) {
        InputStream in = plugin.getResource("lang/" + c + ".yml");
        if (in == null) return null;
        return YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    /** Дописує в мовний файл нові ключі з оновленого плагіна, не чіпаючи вже змінені тексти. */
    private void mergeMissing(File file, String c) {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        YamlConfiguration def = loadJar(c);
        if (def == null) return;

        boolean missing = false;
        for (String key : def.getKeys(true)) {
            if (def.isConfigurationSection(key)) continue;
            if (!y.contains(key, true)) {
                missing = true;
                break;
            }
        }
        if (!missing) return;

        try {
            Files.copy(file.toPath(), new File(file.getParentFile(), c + ".yml.bak").toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
            y.setDefaults(def);
            y.options().copyDefaults(true);
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Cannot update lang/" + c + ".yml: " + ex.getMessage());
        }
    }

    /**
     * Старі версії зберігали тексти в config.yml (prefix, gui.main-title, messages).
     * При першому створенні uk.yml переносимо їх, щоб не втратити налаштовані тексти.
     */
    private void migrateLegacy(File ukFile) {
        YamlConfiguration def = loadJar("uk");
        if (def == null) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(ukFile);
        var cfg = plugin.getConfig();
        boolean changed = false;

        if (cfg.contains("prefix", true) && def.contains("prefix")) {
            y.set("prefix", cfg.getString("prefix"));
            changed = true;
        }
        if (cfg.contains("gui.main-title", true) && def.contains("menu.main-title")) {
            y.set("menu.main-title", cfg.getString("gui.main-title"));
            changed = true;
        }
        ConfigurationSection msgs = cfg.getConfigurationSection("messages");
        if (msgs != null) {
            for (String key : msgs.getKeys(false)) {
                if (def.contains("messages." + key) && msgs.isString(key)) {
                    y.set("messages." + key, msgs.getString(key));
                    changed = true;
                }
            }
        }
        if (!changed) return;
        try {
            y.save(ukFile);
            plugin.getLogger().info("Texts from config.yml were moved to lang/uk.yml");
        } catch (IOException ex) {
            plugin.getLogger().warning("Cannot migrate texts to lang/uk.yml: " + ex.getMessage());
        }
    }

    /** Текст без кольорів, з підстановкою пар {плейсхолдер}/значення. */
    public String raw(String key, Object... kv) {
        String s = lang.getString(key);
        if (s == null) return "Missing text: " + key;
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace(String.valueOf(kv[i]), String.valueOf(kv[i + 1]));
        }
        return s;
    }

    /** Текст із кольорами (&amp;-коди) і підстановкою. */
    public String text(String key, Object... kv) {
        return Util.color(raw(key, kv));
    }
}
