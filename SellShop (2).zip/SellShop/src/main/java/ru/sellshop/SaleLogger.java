package ru.sellshop;

import org.bukkit.Bukkit;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Дописує рядки в plugins/SellShop/sales.log (в асинхронному потоці). */
public class SaleLogger {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final SellShop plugin;
    private final File file;

    public SaleLogger(SellShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "sales.log");
    }

    public void log(String line) {
        final String out = "[" + LocalDateTime.now().format(FMT) + "] " + line + System.lineSeparator();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            synchronized (this) {
                try (FileWriter w = new FileWriter(file, StandardCharsets.UTF_8, true)) {
                    w.write(out);
                } catch (IOException e) {
                    plugin.getLogger().severe(plugin.lang().raw("log.sales-log-failed", "{error}", e.getMessage()));
                }
            }
        });
    }
}
