package ru.sellshop;

import org.bukkit.entity.Player;

/** Валюта, в якій гравець отримує оплату. Дозволяє легко додати донатну валюту. */
public interface Currency {
    /** Видати гравцю гроші. true — успішно. Викликається з основного потоку. */
    boolean give(Player player, double amount);

    /** Назва валюти, наприклад "монет". */
    String name();

    /** Гарне подання суми, наприклад "12.5 монет". */
    String format(double amount);
}
