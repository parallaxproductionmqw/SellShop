package ru.sellshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public class SellShop extends JavaPlugin {
    private ShopManager shop;
    private StatsManager stats;
    private SaleLogger sales;
    private Lang lang;
    private CurrencyManager currencies;
    private SellService service;
    private SellGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        List<String> addedOptions = mergeConfigDefaults();
        lang = new Lang(this);
        if (!addedOptions.isEmpty()) {
            getLogger().info(lang.raw("log.config-updated", "{keys}", String.join(", ", addedOptions)));
        }
        createDefaultShop();

        currencies = new CurrencyManager(this);
        shop = new ShopManager(this);
        shop.load();
        stats = new StatsManager(this);
        stats.load();
        sales = new SaleLogger(this);
        service = new SellService(this);
        gui = new SellGUI(this);

        getServer().getPluginManager().registerEvents(gui, this);

        getCommand("sell").setExecutor(new SellCommand(this));
        AdminCommand admin = new AdminCommand(this);
        getCommand("selladmin").setExecutor(admin);
        getCommand("selladmin").setTabCompleter(admin);

        // зберігаємо лічильник раз на 30 секунд (якщо були зміни)
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> stats.saveIfDirty(), 600L, 600L);

        // попередження, якщо немає економіки (перевіряємо після завантаження всіх плагінів)
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (Bukkit.getServicesManager().getRegistration(Economy.class) == null) {
                getLogger().warning(lang.raw("log.vault-warning"));
            }
        }, 100L);

        getLogger().info(lang.raw("log.enabled", "{count}", shop.categories().size()));
    }

    @Override
    public void onDisable() {
        if (stats != null) stats.saveIfDirty();
    }

    /**
     * Дописує в config.yml нові ключі з нової версії плагіна, не чіпаючи значень, які вже налаштовані.
     * Перед змінами робиться копія config.yml.bak.
     */
    private List<String> mergeConfigDefaults() {
        FileConfiguration cfg = getConfig();
        Configuration def = cfg.getDefaults();
        if (def == null) return List.of();

        List<String> missing = new ArrayList<>();
        for (String key : def.getKeys(true)) {
            if (def.isConfigurationSection(key)) continue;
            if (!cfg.contains(key, true)) missing.add(key);
        }
        if (missing.isEmpty()) return missing;

        try {
            File conf = new File(getDataFolder(), "config.yml");
            Files.copy(conf.toPath(), new File(getDataFolder(), "config.yml.bak").toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            getLogger().warning("Cannot create config.yml.bak: " + ex.getMessage());
        }
        cfg.options().copyDefaults(true);
        saveConfig();
        return missing;
    }

    /** Перший запуск: створює shop.yml зі стандартними розділами мовою плагіна. */
    private void createDefaultShop() {
        File shopFile = new File(getDataFolder(), "shop.yml");
        if (shopFile.exists()) return;
        if (!"en".equals(lang.code())) {
            saveResource("shop.yml", false);
            return;
        }
        try (InputStream in = getResource("shop_en.yml")) {
            if (in != null) Files.copy(in, shopFile.toPath());
            else saveResource("shop.yml", false);
        } catch (IOException ex) {
            getLogger().warning("Cannot create shop.yml: " + ex.getMessage());
        }
    }

    public void reloadAll() {
        reloadConfig();
        lang.reload();
        currencies.reload();
        shop.load();
    }

    /** Повідомлення з config.yml з префіксом; пари плейсхолдер/значення: msg("sold", "{amount}", 5, ...). */
    public String msg(String key, Object... kv) {
        return Util.color(lang.raw("prefix") + lang.raw("messages." + key, kv));
    }

    public Lang lang() { return lang; }
    public ShopManager shop() { return shop; }
    public StatsManager stats() { return stats; }
    public SaleLogger sales() { return sales; }
    public CurrencyManager currencies() { return currencies; }
    public SellService service() { return service; }
    public SellGUI gui() { return gui; }
}
