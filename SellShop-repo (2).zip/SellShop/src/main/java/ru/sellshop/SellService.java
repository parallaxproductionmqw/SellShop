package ru.sellshop;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.Map;

/** Логика продажи: списание предметов, выдача денег, статистика, лог. */
public class SellService {
    private final SellShop plugin;

    public SellService(SellShop plugin) {
        this.plugin = plugin;
    }

    /** Предмет без имени/зачарований и т.п. — только такие продаются. */
    private static boolean isPlain(ItemStack it) {
        return it != null && !it.hasItemMeta();
    }

    public int count(Player p, Material m) {
        int n = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && it.getType() == m && isPlain(it)) n += it.getAmount();
        }
        return n;
    }

    private int remove(Player p, Material m, int limit) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getStorageContents();
        int left = limit;
        int removed = 0;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack it = contents[i];
            if (it == null || it.getType() != m || !isPlain(it)) continue;
            int take = Math.min(left, it.getAmount());
            removed += take;
            left -= take;
            if (take >= it.getAmount()) contents[i] = null;
            else it.setAmount(it.getAmount() - take);
        }
        if (removed > 0) inv.setStorageContents(contents);
        return removed;
    }

    /** Вернуть предметы игроку (остаток падает на пол). */
    public void giveItems(Player p, Material m, long amount) {
        long rest = amount;
        int max = m.getMaxStackSize();
        while (rest > 0) {
            int n = (int) Math.min(rest, max);
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, n));
            Location loc = p.getLocation();
            for (ItemStack s : left.values()) {
                p.getWorld().dropItemNaturally(loc, s);
            }
            rest -= n;
        }
    }

    /**
     * @param all false — продать один стак, true — продать всё из инвентаря
     */
    public void sell(Player p, Category c, Material m, boolean all) {
        Double price = c.items.get(m);
        if (price == null) return;

        Currency currency = plugin.currencies().get(c.currency);
        if (currency == null) {
            p.sendMessage(plugin.msg("currency-unavailable"));
            return;
        }

        int limit = all ? Integer.MAX_VALUE : m.getMaxStackSize();
        int removed = remove(p, m, limit);
        if (removed <= 0) {
            p.sendMessage(plugin.msg("nothing-to-sell", "{item}", Util.name(m)));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }

        double total = Util.round2(price * removed);
        if (!currency.give(p, total)) {
            giveItems(p, m, removed);
            p.sendMessage(plugin.msg("economy-error"));
            return;
        }

        plugin.stats().add(m, removed);
        plugin.sales().log(String.format("SELL %s sold %dx %s for %s (%s, category=%s, mode=%s)",
                p.getName(), removed, m.name(), Util.num(total), c.currency, c.id, all ? "all" : "stack"));

        p.sendMessage(plugin.msg("sold",
                "{amount}", removed,
                "{item}", Util.name(m),
                "{money}", currency.format(total)));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
    }
}
