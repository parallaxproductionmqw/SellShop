package ru.sellshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Счётчик: сколько каждого предмета продали игроки (лежит «на складе»).
 * Админ может забрать предметы командой /selladmin take.
 */
public class StatsManager {
    private final SellShop plugin;
    private final File file;
    private final Map<Material, Long> sold = new HashMap<>();
    private boolean dirty = false;

    public StatsManager(SellShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
    }

    public synchronized void load() {
        sold.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("sold");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            Material m = Material.matchMaterial(key);
            long n = sec.getLong(key);
            if (m != null && n > 0) sold.put(m, n);
        }
    }

    public synchronized void add(Material m, long amount) {
        sold.merge(m, amount, Long::sum);
        dirty = true;
    }

    public synchronized long get(Material m) {
        return sold.getOrDefault(m, 0L);
    }

    /** Списать из счётчика до amount штук. Возвращает, сколько реально списано. */
    public synchronized long take(Material m, long amount) {
        long have = get(m);
        long taken = Math.min(have, amount);
        if (taken <= 0) return 0;
        if (have - taken <= 0) sold.remove(m);
        else sold.put(m, have - taken);
        dirty = true;
        return taken;
    }

    /** Список «предмет — количество», по убыванию количества. */
    public synchronized List<Map.Entry<Material, Long>> sorted() {
        List<Map.Entry<Material, Long>> list = new ArrayList<>(sold.entrySet());
        list.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        return list;
    }

    public synchronized void saveIfDirty() {
        if (!dirty) return;
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<Material, Long> e : sold.entrySet()) {
            y.set("sold." + e.getKey().name(), e.getValue());
        }
        try {
            y.save(file);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить stats.yml: " + ex.getMessage());
        }
    }
}
