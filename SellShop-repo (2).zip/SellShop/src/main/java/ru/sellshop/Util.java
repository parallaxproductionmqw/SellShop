package ru.sellshop;

import org.bukkit.ChatColor;
import org.bukkit.Material;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Util {
    private Util() {}

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    public static String num(double d) {
        return new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(Locale.US)).format(d);
    }

    public static double round2(double d) {
        return Math.round(d * 100.0) / 100.0;
    }

    /** STONE_BRICKS -> Stone Bricks */
    public static String name(Material m) {
        String[] parts = m.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }
}
