package ru.sellshop;

import org.bukkit.entity.Player;

/** Валюта, в которой игрок получает оплату. Позволяет легко добавить донатную валюту. */
public interface Currency {
    /** Выдать игроку деньги. true — успешно. Вызывается из основного потока. */
    boolean give(Player player, double amount);

    /** Красивое представление суммы, например "12.5 монет". */
    String format(double amount);
}
