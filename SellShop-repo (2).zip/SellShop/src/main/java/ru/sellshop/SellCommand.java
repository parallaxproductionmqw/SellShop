package ru.sellshop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SellCommand implements CommandExecutor {
    private final SellShop plugin;

    public SellCommand(SellShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("players-only"));
            return true;
        }
        if (!p.hasPermission("sellshop.use")) {
            p.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        plugin.gui().openMain(p);
        return true;
    }
}
