package ru.sellshop;

import org.bukkit.Material;

import java.util.LinkedHashMap;

public class Category {
    public final String id;
    public String title;
    public Material icon;
    public int slot;
    public String currency;
    /** Предмет -> ціна за 1 шт. (продається лише повними стаками). */
    public final LinkedHashMap<Material, Double> items = new LinkedHashMap<>();

    public Category(String id, String title, Material icon, int slot, String currency) {
        this.id = id;
        this.title = title;
        this.icon = icon;
        this.slot = slot;
        this.currency = currency;
    }
}
