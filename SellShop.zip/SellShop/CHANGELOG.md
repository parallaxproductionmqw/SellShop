# Changelog

## 1.4.1-hotfix

A hotfix for 1.4.1: one restored feature and fixes for ways to lose data, abuse the sale or overload the server.

### Restored
- After "Sell everything" (and after "No") the player returns to the categories menu, on the same page the button was on (before, always the first page).

### Security and stability
- **A broken `shop.yml` no longer wipes the shop.** The file is now read strictly: on a syntax error the previous data stays in memory, a copy of the broken file is saved as `shop.yml.broken`, an error is logged, and saving is blocked until the file is fixed and `/sa reload` succeeds. Before, a typo made the shop empty and the next admin action overwrote the file. `/sa reload` and the panel's reload button now say when the file was not reloaded, and `/sa add|put|remove|price|unit|addcategory|removecategory` refuse to run while saving is blocked.
- **The server can no longer be flooded with item entities from the counter.** `/sa take` and Shift+click in the counter give at most 36 stacks at once; the rest stays in the counter. Before, taking e.g. 500 000 cobblestone dropped thousands of entities on the floor and could freeze or crash the server.
- **"Sell everything" pays exactly what was shown.** The confirmation menu remembers the plan; if the inventory or prices changed before "Yes", nothing is sold, the player is told, and the menu is reopened with the new total.
- **Only plain clicks work in the menus.** The sell menu and the admin panel react to left/right click (with or without Shift) only; double click, number keys, Q and the middle button do nothing.

### Fixed
- **Items with price 0 are no longer taken for nothing.** An item whose price is 0 (or was invalid or too small in `shop.yml`) is not for sale: `sell`, shift-click and "Sell everything" skip it and say so. `shop.yml` entries with a zero or invalid price are reported in the log.

### Changed
- Corrected the 1.4 claim about hiding `/sa`: the command is registered with the permission `sellshop.admin`, which hides it from players' tab completion, but the message shown on typing it is up to the server. The README no longer promises a specific message.
- New texts (added to your language files automatically): `messages.not-for-sale`, `sell-all-changed`, `take-limited`, `reload-shop-failed`, `shop-save-blocked` and `log.shop-load-failed`, `shop-save-blocked`, `zero-price`.
- New texts (added to your language files automatically): `messages.not-for-sale`, `sell-all-changed`, `take-limited`, `reload-shop-failed`, `shop-save-blocked` and `log.shop-load-failed`, `shop-save-blocked`, `zero-price`.

## 1.4.1

### Added
- **Selling from creative mode is admin-only.** New permission `sellshop.creative` (default: operators, included in `sellshop.admin`). Other players in creative mode get a message, and the "Sell everything" button says so.
- **Everything is editable from the admin panel.**
  - Item screen: `-10 / -1 / -0.1` and `+0.1 / +1 / +10` price buttons (Shift = step ×10); exact values are typed in chat (the message is hidden from other players, `cancel` aborts).
  - Add items by clicking them in your inventory, with the item in hand, or by name (`ITEM [amount] price`).
  - New **category settings** screen: title, icon, menu slot, currency.
  - New **Settings** screen: slot and icon of the "Sell everything" button, main menu rows, filler, full-stack display, money name, donate currency (on/off, name, command), prefix, menu titles and any text of the language file by key.
  - The categories list in the panel now has pages.
- Config option `currencies.donate.whole-amounts` (default `true`).
- New text keys: `panel.catset.*`, `panel.settings.*`, `panel.item.adjust*`, `panel.category.settings*`, `panel.category.add-name*`, `panel.state-on/off`, `menu.sell-all-creative` and the `prompt-*`, `price-too-high`, `invalid-id`, `creative-denied`, `payout-too-small`, `shop-changed` and other messages. The old `panel-suggest` and `panel-hint-*` texts are no longer used.

### Fixed
- **Categories are never dropped from the menu.** The main menu grows up to 6 rows and then gets pages (before, categories that did not fit were silently cut). The admin category list got pages too.
- **Sales log and counter are not lost on stop.** One queue and one task write `sales.log`; `onDisable` flushes it. The counter is saved every 5 seconds (was 30) and on shutdown, and `stats.yml` is written atomically.
- **Donate payout can no longer give both currency and items.** A `false` result of the console command is trusted only when the command does not exist. Leading `/` in the command is stripped, amounts are whole numbers by default, and payouts below 1 are refused before items are taken.
- **`shop.yml` is saved safely:** through a temporary file and an atomic move, keeping your comments and unknown keys. The outdated header ("only full stacks", old commands) is replaced.
- The menu sells exactly what the player saw: if an admin changes prices or items while a category is open, nothing is sold and the menu is refreshed.
- A price is limited to 1 000 000 000 (the panel, the commands and `shop.yml` all respect this), so `round2` can no longer overflow.
- The `kinds` counter in the "sold everything" message counts different items, not entries.
- Item icons hide attributes and extra tooltips (swords, tools, potions).
- `Lang.loadJar` closes its stream.
- `getHolder(false)` is used in click and drag handlers, so no block snapshot is made for other inventories.
- Menus opened from a click are opened on the next tick.
- A gray glass pane that is a category icon or an item in the panel can now be clicked.
- "Add item" with an empty hand shows the `hold-item` message.
- Category ids are checked (`a-z`, `0-9`, `_`, `-`).

### Build
- `plugin.yml` takes the version from `pom.xml` (it is quoted, so `1.10` can no longer become `1.1`).
- `maven-compiler-plugin` 3.14.0 with `maven.compiler.release` 25.
- The old `.github/workflows/build.yml` was removed from the archive.

## 1.4

### Added
- **Admin panel** opened with `/sa` (or `/sa panel`): categories and items (price, full stack or bundle, bundle size, delete), creating and deleting categories, default language selection, the sold counter (take items), reload and the command list.
- **Quick start** screen in the panel: a short four-step guide for beginners.
- Items are added by clicking them in the player's own inventory while a category is open (or with the item in hand and the green button).
- Clickable chat lines that fill the chat box with a ready command where a number or a name must be typed.
- Shift + left click is required to delete an item or a category.
- New command `/sa put <category> <item> <amount> <price>` (same as `/sa add`, item first).
- New text keys under `panel.*`, `messages.panel-*`, `messages.language-changed`, `admin.help.panel`, `admin.help.put`, `admin.usage.put`.

### Fixed
- Donate currency: player name is checked against `^[A-Za-z0-9_.]{1,20}$` before it is put into the console command; otherwise the payout is refused and the items are returned.
- Payment errors (exceptions) are treated as a failed payment and the items are returned instead of being lost.
- Statistics/log errors no longer interrupt a sale after payment.
- Negative, `NaN` or infinite prices in `shop.yml` are loaded as `0`.

### Changed
- `/sa` is now hidden from players without `sellshop.admin`: no tab completion, no entry in `/help`, and the standard "Unknown command" message instead of a "no permission" text.
- `/sa` without arguments opens the panel for players (the console still gets the command list).

## 1.3.2

### Fixed
- The confirmation menu is now a single chest (3 rows) with three buttons: Yes, No and a central chest that lists what is being sold (item, amount, earnings), the total pieces and the overall total.
- The "Sell everything" button in the main menu shows a short list of the items that will be sold plus the total.
- New text key `confirm.list-line` in the language files; unused keys `confirm.item-amount` and `confirm.item-money` were removed.

## 1.3.1

### Changed
- After selling everything, the player is returned to the categories menu (the main menu) instead of the menu being closed.
- A short "ka-ching" jingle and green sparkles play after a mass sale.
- Defaults for new installs: the "Sell everything" button is a chest in the bottom center (`gui.sell-all-slot: 22`, `gui.sell-all-icon: CHEST`). Existing configs keep their own values.

## 1.3

### Added
- **"Sell everything" button** in the main menu. It counts every item the player can sell across all categories and shows the total in its description.
- **Confirmation menu.** Clicking the button opens a menu with every item that will be sold (amount and earnings for each) and the overall total. **Yes** sells everything at once, **No** returns to the main menu.
- One summary chat message after a mass sale instead of one message per item. Mass sales are written to the sales log and the sales counter like normal ones.
- Works with several currencies: totals are shown and paid separately for each currency. If a payment fails, the items of that currency are returned.
- New `config.yml` options: `gui.sell-all-slot` (`-1` turns the button off) and `gui.sell-all-icon`.
- New texts in `lang/uk.yml` and `lang/en.yml` (added automatically on update, your edited texts are kept).

## 1.2

### Added
- **Sell by stack or by bundle.** Each item is sold either by full stack (default) or by a bundle of N pieces with a price for that amount, e.g. 24 pieces for 1. The menu shows the same amount that is sold, and Shift + click sells as many whole bundles as the player has.
- **Localization.** The whole plugin (menu, messages, admin help, console logs) is available in Ukrainian (default) and English. Switch with `language: uk|en` in `config.yml`. All texts live in `plugins/SellShop/lang/` and can be edited, and you can add your own language file.
- New `/sa unit <category> <item> <amount|stack>` to switch an existing item between bundle and stack selling.
- New `shop.yml` format for bundle items (`mode: piece`, `amount`, `price`). The old format (`STONE: 64.0`) still works.
- **Automatic config update.** On start, missing options are added to `config.yml` and the language files; your existing values are kept and a `.bak` backup is created.

### Changed
- New price format: prices are shown as `<currency name> х<amount>`, e.g. `Дзеньки х64` (`Coins x64` in English).
- Texts moved from `config.yml` (messages, prefix, `gui.main-title`) to `lang/uk.yml`. Customized texts are copied automatically on the first start; the old entries in `config.yml` are no longer used. Set `currencies.vault.name: ""` to use the language's default currency name.
- **Breaking:** `/sa add` now requires the amount: `/sa add <category> <amount> <price> [item]`. Without an item name, the item in hand is used.
