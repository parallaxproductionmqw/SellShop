# Changelog

## 1.3

### Added
- **"Sell everything" button** in the main menu (start of the second row). It counts every item the player can sell across all categories and shows the total in its description.
- **Confirmation menu.** Clicking the button opens a menu with every item that will be sold (amount and earnings for each) and the overall total. **Yes** sells everything at once, **No** returns to the main menu.
- One summary chat message after a mass sale instead of one message per item. Mass sales are written to the sales log and the sales counter like normal ones.
- Works with several currencies: totals are shown and paid separately for each currency. If a payment fails, the items of that currency are returned.
- New `config.yml` options: `gui.sell-all-slot` (default `9`, `-1` turns the button off) and `gui.sell-all-icon` (default `EMERALD`).
- New texts in `lang/uk.yml` and `lang/en.yml` (added automatically on update, your edited texts are kept).

## 1.2
- Previous release.
