package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Дописує рядки в plugins/SellShop/sales.log.
 * Рядки складаються в одну чергу, яку раз на секунду (в асинхронному потоці) скидає на диск одна задача.
 * При вимкненні плагіна Bukkit скасовує асинхронні задачі, тому {@link #close()} скидає чергу сам.
 */
public class SaleLogger {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final SellShop plugin;
    private final File file;
    private final ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
    private final Object writeLock = new Object();
    private BukkitTask task;

    public SaleLogger(SellShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "sales.log");
        this.task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::flush, 20L, 20L);
    }

    public void log(String line) {
        queue.add("[" + LocalDateTime.now().format(FMT) + "] " + line + System.lineSeparator());
    }

    /** Записує все, що накопичилось у черзі. Безпечно викликати з будь-якого потоку. */
    public void flush() {
        synchronized (writeLock) {
            if (queue.isEmpty()) return;
            List<String> batch = new ArrayList<>();
            String line;
            while ((line = queue.poll()) != null) batch.add(line);
            try (FileWriter w = new FileWriter(file, StandardCharsets.UTF_8, true)) {
                for (String l : batch) w.write(l);
            } catch (IOException e) {
                plugin.getLogger().severe(plugin.lang().raw("log.sales-log-failed", "{error}", e.getMessage()));
            }
        }
    }

    /** Викликається з onDisable: зупиняє задачу й скидає чергу на диск. */
    public void close() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        flush();
    }
}
