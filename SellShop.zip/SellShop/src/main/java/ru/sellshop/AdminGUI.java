package ru.sellshop;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Адмін-панель (/sa): усе, що можна робити командами, тепер можна кнопками.
 * Де потрібне число чи текст, панель закриває меню і просить написати значення в чат
 * (це повідомлення нікому не показується); слово «cancel» скасовує введення.
 */
public class AdminGUI implements Listener {
    private static final int PER_PAGE = 45;
    private static final Pattern CATEGORY_ID = Pattern.compile("^[a-z0-9_-]{1,32}$");
    private static final List<String> CANCEL_WORDS = List.of("cancel", "відміна", "скасувати", "отмена");

    private enum Screen { MAIN, CATEGORIES, CATEGORY, CATSET, ITEM, LANGUAGE, STATS, HELP, SETTINGS }

    public static class Holder implements InventoryHolder {
        final Screen screen;
        final String category;
        final Material material;
        final int page;
        final Map<Integer, String> keys = new HashMap<>();
        final Map<Integer, Material> mats = new HashMap<>();
        private Inventory inventory;

        Holder(Screen screen, String category, Material material, int page) {
            this.screen = screen;
            this.category = category;
            this.material = material;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    /** Очікуване введення з чату від одного адміна. */
    private record Prompt(Consumer<String> handler, Runnable onCancel) {}

    private final SellShop plugin;
    private final Map<UUID, Prompt> prompts = new ConcurrentHashMap<>();

    public AdminGUI(SellShop plugin) {
        this.plugin = plugin;
    }

    /** Викликається з onDisable. */
    public void shutdown() {
        prompts.clear();
    }

    // ───────────────────────── помічники ─────────────────────────

    private ItemStack icon(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        if (lore != null && !lore.isEmpty()) meta.setLore(lore);
        Util.hideExtras(meta);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack pane() {
        return icon(Material.GRAY_STAINED_GLASS_PANE, " ", null);
    }

    /** Текст із \n розбивається на рядки опису. */
    private List<String> lines(String key, Object... kv) {
        return new ArrayList<>(Arrays.asList(plugin.lang().text(key, kv).split("\n", -1)));
    }

    private String text(String key, Object... kv) {
        return plugin.lang().text(key, kv);
    }

    private Inventory create(Holder h, int size, String title) {
        Inventory inv = Bukkit.createInventory(h, size, title);
        h.inventory = inv;
        ItemStack pane = pane();
        for (int i = 0; i < size; i++) inv.setItem(i, pane);
        return inv;
    }

    private void clearRow(Inventory inv, int from, int to) {
        for (int i = from; i < to; i++) inv.setItem(i, null);
    }

    private static int pagesFor(int size) {
        return Math.max(1, (int) Math.ceil(size / (double) PER_PAGE));
    }

    /** Виконати на наступному тіку: відкривати інші меню прямо всередині InventoryClickEvent ненадійно. */
    private void later(Runnable r) {
        Bukkit.getScheduler().runTask(plugin, r);
    }

    static String languageName(String code) {
        return switch (code) {
            case "uk" -> "Українська";
            case "en" -> "English";
            case "ru" -> "Русский";
            default -> code;
        };
    }

    private String onOff(boolean b) {
        return text(b ? "panel.state-on" : "panel.state-off");
    }

    // ───────────────────────── введення з чату ─────────────────────────

    /** Закриває меню, показує підказку і чекає наступне повідомлення гравця в чаті. */
    private void ask(Player p, String hint, Runnable onCancel, Consumer<String> handler) {
        prompts.put(p.getUniqueId(), new Prompt(handler, onCancel));
        later(() -> {
            p.closeInventory();
            p.sendMessage(hint);
            p.sendMessage(plugin.msg("prompt-cancel"));
        });
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        Prompt pr = prompts.remove(p.getUniqueId());
        if (pr == null) return;
        e.setCancelled(true); // значення ціни/назви не повинно потрапити в загальний чат
        String msg = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline() || !p.hasPermission("sellshop.admin")) return;
            if (msg.isEmpty() || CANCEL_WORDS.contains(msg.toLowerCase(Locale.ROOT))) {
                p.sendMessage(plugin.msg("cancelled"));
                if (pr.onCancel() != null) pr.onCancel().run();
                return;
            }
            try {
                pr.handler().accept(msg);
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Admin panel input failed: " + ex);
                p.sendMessage(plugin.msg("economy-error"));
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        prompts.remove(e.getPlayer().getUniqueId());
    }

    // ───────────────────────── розбір введення ─────────────────────────

    /** Ціна з чату: число від 0 до Util.MAX_PRICE. null — вже повідомили гравцю про помилку. */
    private Double parsePrice(Player p, String raw) {
        double d;
        try {
            d = Double.parseDouble(raw.replace(',', '.'));
        } catch (NumberFormatException ex) {
            p.sendMessage(plugin.msg("invalid-number", "{value}", raw));
            return null;
        }
        if (Double.isNaN(d) || Double.isInfinite(d) || d < 0) {
            p.sendMessage(plugin.msg("invalid-number", "{value}", raw));
            return null;
        }
        if (d > Util.MAX_PRICE) {
            p.sendMessage(plugin.msg("price-too-high", "{max}", Util.num(Util.MAX_PRICE)));
            return null;
        }
        return d;
    }

    private Integer parseInt(Player p, String raw, int min, int max) {
        try {
            int n = Integer.parseInt(raw);
            if (n >= min && n <= max) return n;
        } catch (NumberFormatException ignored) {
            // нижче скажемо про помилку
        }
        p.sendMessage(plugin.msg("invalid-number", "{value}", raw));
        return null;
    }

    private Material parseMaterial(Player p, String raw) {
        Material m = Material.matchMaterial(raw);
        if (m == null || !m.isItem() || m.isAir()) {
            p.sendMessage(plugin.msg("invalid-item", "{item}", raw));
            return null;
        }
        return m;
    }

    // ───────────────────────── екрани ─────────────────────────

    public void openMain(Player p) {
        if (plugin.shop().isSaveBlocked()) p.sendMessage(plugin.msg("shop-save-blocked"));
        Holder h = new Holder(Screen.MAIN, null, null, 0);
        Inventory inv = create(h, 27, text("panel.main.title"));

        inv.setItem(4, icon(Material.KNOWLEDGE_BOOK, text("panel.main.help"), lines("panel.main.help-lore")));
        inv.setItem(10, icon(Material.CHEST, text("panel.main.categories"),
                lines("panel.main.categories-lore", "{count}", plugin.shop().categories().size())));
        inv.setItem(12, icon(Material.NETHER_STAR, text("panel.main.settings"), lines("panel.main.settings-lore")));
        inv.setItem(14, icon(Material.WRITABLE_BOOK, text("panel.main.language"),
                lines("panel.main.language-lore", "{language}", languageName(plugin.lang().code()))));
        inv.setItem(16, icon(Material.BARREL, text("panel.main.stats"),
                lines("panel.main.stats-lore", "{kinds}", plugin.stats().sorted().size())));
        inv.setItem(20, icon(Material.COMPARATOR, text("panel.main.reload"), lines("panel.main.reload-lore")));
        inv.setItem(22, icon(Material.PAPER, text("panel.main.commands"), lines("panel.main.commands-lore")));
        inv.setItem(26, icon(Material.BARRIER, text("panel.close"), null));
        p.openInventory(inv);
    }

    public void openCategories(Player p) {
        openCategories(p, 0);
    }

    public void openCategories(Player p, int page) {
        List<Category> list = new ArrayList<>(plugin.shop().categories());
        int pages = pagesFor(list.size());
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(Screen.CATEGORIES, null, null, pg);
        Inventory inv = create(h, 54, text("panel.categories.title"));
        clearRow(inv, 0, PER_PAGE);

        int from = pg * PER_PAGE;
        for (int i = from; i < Math.min(list.size(), from + PER_PAGE); i++) {
            Category c = list.get(i);
            int slot = i - from;
            inv.setItem(slot, icon(c.icon, Util.color(c.title),
                    lines("panel.categories.item-lore", "{id}", c.id, "{count}", c.items.size(),
                            "{currency}", c.currency)));
            h.keys.put(slot, c.id);
        }
        if (pg > 0) inv.setItem(45, icon(Material.ARROW, text("menu.prev"), null));
        inv.setItem(46, icon(Material.ARROW, text("panel.back"), null));
        inv.setItem(49, icon(Material.EMERALD, text("panel.categories.add"), lines("panel.categories.add-lore")));
        if (pg < pages - 1) inv.setItem(53, icon(Material.ARROW, text("menu.next"), null));
        p.openInventory(inv);
    }

    public void openCategory(Player p, String id, int page) {
        Category c = plugin.shop().get(id);
        if (c == null) {
            openCategories(p);
            return;
        }
        List<Map.Entry<Material, Double>> entries = new ArrayList<>(c.items.entrySet());
        int pages = pagesFor(entries.size());
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(Screen.CATEGORY, c.id, null, pg);
        Inventory inv = create(h, 54, text("panel.category.title", "{category}", c.id));
        clearRow(inv, 0, PER_PAGE);

        int from = pg * PER_PAGE;
        for (int i = from; i < Math.min(entries.size(), from + PER_PAGE); i++) {
            Material m = entries.get(i).getKey();
            int slot = i - from;
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(priceLine(c, m));
            lore.add("");
            lore.add(text("panel.category.item-click"));
            meta.setLore(lore);
            Util.hideExtras(meta);
            it.setItemMeta(meta);
            inv.setItem(slot, it);
            h.mats.put(slot, m);
        }

        if (pg > 0) inv.setItem(45, icon(Material.ARROW, text("menu.prev"), null));
        inv.setItem(46, icon(Material.ARROW, text("panel.back"), null));
        inv.setItem(47, icon(Material.COMPARATOR, text("panel.category.settings"),
                lines("panel.category.settings-lore")));
        inv.setItem(48, icon(Material.LIME_DYE, text("panel.category.add"), lines("panel.category.add-lore")));
        inv.setItem(49, icon(Material.NAME_TAG, text("panel.category.add-name"), lines("panel.category.add-name-lore")));
        inv.setItem(50, icon(Material.TNT, text("panel.category.remove"), lines("panel.category.remove-lore")));
        if (pg < pages - 1) inv.setItem(53, icon(Material.ARROW, text("menu.next"), null));
        p.openInventory(inv);
    }

    private String priceLine(Category c, Material m) {
        String price = plugin.currencies().format(c.currency, c.items.get(m));
        return c.isPiece(m)
                ? text("item.price-piece", "{amount}", c.unit(m), "{price}", price)
                : text("item.price-stack", "{amount}", m.getMaxStackSize(), "{price}", price);
    }

    /** Параметри розділу: назва, іконка, слот, валюта. */
    public void openCategorySettings(Player p, String categoryId) {
        Category c = plugin.shop().get(categoryId);
        if (c == null) {
            openCategories(p);
            return;
        }
        Holder h = new Holder(Screen.CATSET, c.id, null, 0);
        Inventory inv = create(h, 27, text("panel.catset.title", "{category}", c.id));

        inv.setItem(4, icon(c.icon, Util.color(c.title), lines("panel.catset.info-lore", "{id}", c.id)));
        inv.setItem(10, icon(Material.NAME_TAG, text("panel.catset.name"),
                lines("panel.catset.name-lore", "{value}", c.title)));
        inv.setItem(12, icon(Material.ITEM_FRAME, text("panel.catset.icon"),
                lines("panel.catset.icon-lore", "{value}", c.icon.name())));
        inv.setItem(14, icon(Material.HOPPER, text("panel.catset.slot"),
                lines("panel.catset.slot-lore", "{value}", c.slot < 0 ? text("panel.catset.slot-auto") : c.slot)));
        inv.setItem(16, icon(Material.GOLD_NUGGET, text("panel.catset.currency"),
                lines("panel.catset.currency-lore", "{value}", c.currency)));
        inv.setItem(22, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    public void openItem(Player p, String categoryId, Material m) {
        Category c = plugin.shop().get(categoryId);
        if (c == null) {
            openCategories(p);
            return;
        }
        if (!c.items.containsKey(m)) {
            openCategory(p, c.id, 0);
            return;
        }
        boolean piece = c.isPiece(m);
        int unit = c.unit(m);
        String price = plugin.currencies().format(c.currency, c.items.get(m));

        Holder h = new Holder(Screen.ITEM, c.id, m, 0);
        Inventory inv = create(h, 36, text("panel.item.title", "{item}", Util.name(m)));

        List<String> infoLore = new ArrayList<>();
        infoLore.add(priceLine(c, m));
        inv.setItem(4, icon(m, Util.color("&f" + Util.name(m)), infoLore));

        inv.setItem(10, icon(Material.GOLD_INGOT, text("panel.item.price"),
                lines("panel.item.price-lore", "{price}", price)));
        if (piece) {
            inv.setItem(12, icon(Material.COMPARATOR, text("panel.item.mode-piece", "{amount}", unit),
                    lines("panel.item.mode-piece-lore", "{amount}", unit)));
            inv.setItem(14, icon(Material.REPEATER, text("panel.item.amount"),
                    lines("panel.item.amount-lore", "{amount}", unit)));
        } else {
            inv.setItem(12, icon(Material.COMPARATOR, text("panel.item.mode-stack"),
                    lines("panel.item.mode-stack-lore")));
        }
        inv.setItem(16, icon(Material.TNT, text("panel.item.remove"), lines("panel.item.remove-lore")));

        // швидка зміна ціни: ЛКМ — на крок, Shift + ЛКМ — на крок ×10
        inv.setItem(19, adjust(Material.RED_CONCRETE, "-10"));
        inv.setItem(20, adjust(Material.RED_CONCRETE, "-1"));
        inv.setItem(21, adjust(Material.RED_CONCRETE, "-0.1"));
        inv.setItem(23, adjust(Material.LIME_CONCRETE, "+0.1"));
        inv.setItem(24, adjust(Material.LIME_CONCRETE, "+1"));
        inv.setItem(25, adjust(Material.LIME_CONCRETE, "+10"));

        inv.setItem(31, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    private ItemStack adjust(Material m, String step) {
        return icon(m, text("panel.item.adjust", "{step}", step), lines("panel.item.adjust-lore"));
    }

    public void openLanguage(Player p) {
        Holder h = new Holder(Screen.LANGUAGE, null, null, 0);
        Inventory inv = create(h, 27, text("panel.language.title"));
        inv.setItem(4, icon(Material.BOOK, text("panel.language.info"), lines("panel.language.info-lore")));

        File dir = new File(plugin.getDataFolder(), "lang");
        File[] files = dir.listFiles((d, n) -> n.endsWith(".yml"));
        List<String> codes = new ArrayList<>();
        if (files != null) {
            for (File f : files) {
                String n = f.getName();
                codes.add(n.substring(0, n.length() - 4));
            }
        }
        Collections.sort(codes);

        String current = plugin.lang().code();
        int slot = 10;
        for (String code : codes) {
            if (slot > 16) break;
            boolean active = code.equals(current);
            ItemStack it = icon(Material.PAPER, Util.color("&f&l" + languageName(code)),
                    new ArrayList<>(List.of(active ? text("panel.language.current") : text("panel.language.click"))));
            if (active) {
                ItemMeta meta = it.getItemMeta();
                meta.setEnchantmentGlintOverride(true);
                it.setItemMeta(meta);
            }
            inv.setItem(slot, it);
            h.keys.put(slot, code);
            slot++;
        }
        inv.setItem(26, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    /** Загальні налаштування: «Продати все», вигляд меню, валюти, тексти. */
    public void openSettings(Player p) {
        var cfg = plugin.getConfig();
        Holder h = new Holder(Screen.SETTINGS, null, null, 0);
        Inventory inv = create(h, 36, text("panel.settings.title"));

        int sellSlot = cfg.getInt("gui.sell-all-slot", 22);
        Material sellIcon = Material.matchMaterial(cfg.getString("gui.sell-all-icon", "CHEST"));
        if (sellIcon == null || sellIcon.isAir() || !sellIcon.isItem()) sellIcon = Material.CHEST;
        String vaultName = cfg.getString("currencies.vault.name", "");
        String donateName = cfg.getString("currencies.donate.name", "");

        inv.setItem(10, icon(Material.HOPPER, text("panel.settings.sell-slot"),
                lines("panel.settings.sell-slot-lore", "{value}", sellSlot < 0 ? text("panel.state-off") : sellSlot)));
        inv.setItem(11, icon(sellIcon, text("panel.settings.sell-icon"),
                lines("panel.settings.sell-icon-lore", "{value}", sellIcon.name())));
        inv.setItem(12, icon(Material.CHEST_MINECART, text("panel.settings.rows"),
                lines("panel.settings.rows-lore", "{value}", cfg.getInt("gui.main-rows", 3))));
        inv.setItem(13, icon(Material.GRAY_STAINED_GLASS, text("panel.settings.filler"),
                lines("panel.settings.filler-lore", "{value}", onOff(cfg.getBoolean("gui.filler", true)))));
        inv.setItem(14, icon(Material.CHEST, text("panel.settings.full-stack"),
                lines("panel.settings.full-stack-lore", "{value}", onOff(cfg.getBoolean("gui.show-full-stack", true)))));
        inv.setItem(15, icon(Material.GOLD_INGOT, text("panel.settings.vault-name"),
                lines("panel.settings.vault-name-lore",
                        "{value}", vaultName.isBlank() ? text("panel.settings.from-lang") : vaultName)));
        inv.setItem(16, icon(Material.DIAMOND, text("panel.settings.donate"),
                lines("panel.settings.donate-lore", "{value}", onOff(cfg.getBoolean("currencies.donate.enabled", false)))));

        inv.setItem(19, icon(Material.EMERALD, text("panel.settings.donate-name"),
                lines("panel.settings.donate-name-lore",
                        "{value}", donateName.isBlank() ? text("panel.settings.from-lang") : donateName)));
        inv.setItem(20, icon(Material.COMMAND_BLOCK, text("panel.settings.donate-command"),
                lines("panel.settings.donate-command-lore",
                        "{value}", cfg.getString("currencies.donate.command", ""))));
        inv.setItem(21, icon(Material.NAME_TAG, text("panel.settings.prefix"),
                lines("panel.settings.prefix-lore", "{value}", plugin.lang().raw("prefix"))));
        inv.setItem(22, icon(Material.OAK_SIGN, text("panel.settings.main-title"),
                lines("panel.settings.main-title-lore", "{value}", plugin.lang().raw("menu.main-title"))));
        inv.setItem(23, icon(Material.OAK_HANGING_SIGN, text("panel.settings.sell-title"),
                lines("panel.settings.sell-title-lore", "{value}", plugin.lang().raw("menu.sell-all-title"))));
        inv.setItem(24, icon(Material.WRITABLE_BOOK, text("panel.settings.any-text"),
                lines("panel.settings.any-text-lore")));

        inv.setItem(31, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    /** Міні-довідник для новачків: чотири кроки від порожнього магазину до першої ціни. */
    public void openHelp(Player p) {
        Holder h = new Holder(Screen.HELP, null, null, 0);
        Inventory inv = create(h, 27, text("panel.help.title"));
        inv.setItem(10, icon(Material.CHEST, text("panel.help.step1"), lines("panel.help.step1-lore")));
        inv.setItem(12, icon(Material.LIME_DYE, text("panel.help.step2"), lines("panel.help.step2-lore")));
        inv.setItem(14, icon(Material.GOLD_INGOT, text("panel.help.step3"), lines("panel.help.step3-lore")));
        inv.setItem(16, icon(Material.COMPARATOR, text("panel.help.step4"), lines("panel.help.step4-lore")));
        inv.setItem(22, icon(Material.PAPER, text("panel.main.commands"), lines("panel.main.commands-lore")));
        inv.setItem(26, icon(Material.ARROW, text("panel.back"), null));
        p.openInventory(inv);
    }

    private void sendCommandList(Player p) {
        p.closeInventory();
        for (String key : List.of("header", "panel", "add", "put", "price", "unit", "remove",
                "addcategory", "removecategory", "stats", "take", "reload")) {
            p.sendMessage(plugin.lang().text("admin.help." + key));
        }
    }

    public void openStats(Player p, int page) {
        List<Map.Entry<Material, Long>> list = plugin.stats().sorted();
        int pages = pagesFor(list.size());
        int pg = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(Screen.STATS, null, null, pg);
        Inventory inv = create(h, 54, text("panel.stats.title"));
        clearRow(inv, 0, PER_PAGE);

        int from = pg * PER_PAGE;
        for (int i = from; i < Math.min(list.size(), from + PER_PAGE); i++) {
            Map.Entry<Material, Long> e = list.get(i);
            int slot = i - from;
            inv.setItem(slot, icon(e.getKey(), Util.color("&f" + Util.name(e.getKey())),
                    lines("panel.stats.item-lore", "{amount}", e.getValue(),
                            "{stack}", e.getKey().getMaxStackSize())));
            h.mats.put(slot, e.getKey());
        }
        if (pg > 0) inv.setItem(45, icon(Material.ARROW, text("menu.prev"), null));
        inv.setItem(49, icon(Material.ARROW, text("panel.back"), null));
        if (pg < pages - 1) inv.setItem(53, icon(Material.ARROW, text("menu.next"), null));
        p.openInventory(inv);
    }

    // ───────────────────────── події ─────────────────────────

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        // getHolder(false): не робити знімок блока (для сундуків на сервері це дорого)
        if (e.getInventory().getHolder(false) instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!p.hasPermission("sellshop.admin")) {
            p.closeInventory();
            return;
        }
        // лише звичайні кліки: подвійний клік, цифри, Q, середня кнопка тощо не мають спрацьовувати як дія
        ClickType type = e.getClick();
        if (type != ClickType.LEFT && type != ClickType.SHIFT_LEFT
                && type != ClickType.RIGHT && type != ClickType.SHIFT_RIGHT) return;
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;

        // клік по власному інвентарю гравця: у розділі — додати предмет, у налаштуваннях — вибрати іконку
        if (clicked != e.getView().getTopInventory()) {
            ItemStack cur = e.getCurrentItem();
            if (cur == null || cur.getType().isAir()) return;
            clickOwnInventory(p, h, cur.getType());
            return;
        }

        int slot = e.getSlot();
        ItemStack item = e.getCurrentItem();
        if (item == null) return;
        // сіре скло — лише заглушка. Але якщо воно саме є іконкою розділу чи предметом, на нього можна клікати
        boolean mapped = h.mats.containsKey(slot) || h.keys.containsKey(slot);
        if (item.getType() == Material.GRAY_STAINED_GLASS_PANE && !mapped) return;
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1f);

        switch (h.screen) {
            case MAIN -> clickMain(p, slot);
            case CATEGORIES -> clickCategories(p, h, slot);
            case CATEGORY -> clickCategory(p, h, slot, e.isShiftClick());
            case CATSET -> clickCategorySettings(p, h, slot);
            case ITEM -> clickItem(p, h, slot, e.isShiftClick());
            case LANGUAGE -> clickLanguage(p, h, slot);
            case STATS -> clickStats(p, h, slot, e.isShiftClick());
            case SETTINGS -> clickSettings(p, slot, e.isRightClick());
            case HELP -> clickHelp(p, slot);
        }
    }

    private void clickOwnInventory(Player p, Holder h, Material m) {
        if (!m.isItem() || m.isAir()) return;
        switch (h.screen) {
            case CATEGORY -> {
                Category c = plugin.shop().get(h.category);
                if (c != null) askAddItem(p, c, m);
            }
            case CATSET -> {
                Category c = plugin.shop().get(h.category);
                if (c == null) return;
                c.icon = m;
                plugin.shop().save();
                p.sendMessage(plugin.msg("icon-set", "{value}", m.name()));
                later(() -> openCategorySettings(p, c.id));
            }
            case SETTINGS -> {
                setConfig("gui.sell-all-icon", m.name());
                p.sendMessage(plugin.msg("icon-set", "{value}", m.name()));
                later(() -> openSettings(p));
            }
            default -> { }
        }
    }

    private void clickMain(Player p, int slot) {
        switch (slot) {
            case 4 -> later(() -> openHelp(p));
            case 10 -> later(() -> openCategories(p));
            case 12 -> later(() -> openSettings(p));
            case 14 -> later(() -> openLanguage(p));
            case 16 -> later(() -> openStats(p, 0));
            case 20 -> {
                p.sendMessage(plugin.reloadAll() ? plugin.msg("reloaded") : plugin.msg("reload-shop-failed"));
                later(() -> openMain(p));
            }
            case 22 -> sendCommandList(p);
            case 26 -> later(p::closeInventory);
            default -> { }
        }
    }

    private void clickHelp(Player p, int slot) {
        if (slot == 22) sendCommandList(p);
        else if (slot == 26) later(() -> openMain(p));
    }

    private void clickCategories(Player p, Holder h, int slot) {
        switch (slot) {
            case 45 -> {
                if (h.page > 0) later(() -> openCategories(p, h.page - 1));
            }
            case 53 -> later(() -> openCategories(p, h.page + 1));
            case 46 -> later(() -> openMain(p));
            case 49 -> askNewCategory(p);
            default -> {
                String id = h.keys.get(slot);
                if (id != null) later(() -> openCategory(p, id, 0));
            }
        }
    }

    private void clickCategory(Player p, Holder h, int slot, boolean shift) {
        Category c = plugin.shop().get(h.category);
        if (c == null) {
            later(() -> openCategories(p));
            return;
        }
        Material mat = h.mats.get(slot);
        if (mat != null) {
            later(() -> openItem(p, c.id, mat));
            return;
        }
        switch (slot) {
            case 45 -> {
                if (h.page > 0) later(() -> openCategory(p, c.id, h.page - 1));
            }
            case 53 -> later(() -> openCategory(p, c.id, h.page + 1));
            case 46 -> later(() -> openCategories(p));
            case 47 -> later(() -> openCategorySettings(p, c.id));
            case 48 -> {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) p.sendMessage(plugin.msg("hold-item"));
                else askAddItem(p, c, hand.getType());
            }
            case 49 -> askAddByName(p, c);
            case 50 -> {
                if (!shift) {
                    p.sendMessage(plugin.msg("panel-shift"));
                    return;
                }
                plugin.shop().removeCategory(c.id);
                p.sendMessage(plugin.msg("category-removed", "{category}", c.id));
                later(() -> openCategories(p));
            }
            default -> { }
        }
    }

    private void clickCategorySettings(Player p, Holder h, int slot) {
        Category c = plugin.shop().get(h.category);
        if (c == null) {
            later(() -> openCategories(p));
            return;
        }
        Runnable back = () -> openCategorySettings(p, c.id);
        switch (slot) {
            case 10 -> ask(p, plugin.msg("prompt-title", "{category}", c.id), back, raw -> {
                c.title = raw;
                plugin.shop().save();
                p.sendMessage(plugin.msg("title-set", "{value}", Util.color(raw)));
                back.run();
            });
            case 12 -> {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir() || !hand.getType().isItem()) {
                    p.sendMessage(plugin.msg("icon-hint"));
                    return;
                }
                c.icon = hand.getType();
                plugin.shop().save();
                p.sendMessage(plugin.msg("icon-set", "{value}", c.icon.name()));
                later(back);
            }
            case 14 -> ask(p, plugin.msg("prompt-slot", "{category}", c.id), back, raw -> {
                Integer n = parseInt(p, raw, -1, 53);
                if (n != null) {
                    c.slot = n;
                    plugin.shop().save();
                    p.sendMessage(plugin.msg("slot-set", "{value}", n < 0 ? "auto" : n));
                }
                back.run();
            });
            case 16 -> {
                List<String> ids = new ArrayList<>(List.of("vault"));
                if (plugin.currencies().get("donate") != null) ids.add("donate");
                int idx = ids.indexOf(c.currency);
                c.currency = ids.get((idx + 1) % ids.size());
                plugin.shop().save();
                p.sendMessage(plugin.msg("currency-set", "{value}", c.currency));
                later(back);
            }
            case 22 -> later(() -> openCategory(p, c.id, 0));
            default -> { }
        }
    }

    private void clickItem(Player p, Holder h, int slot, boolean shift) {
        Category c = plugin.shop().get(h.category);
        Material m = h.material;
        if (c == null || m == null || !c.items.containsKey(m)) {
            later(() -> openCategories(p));
            return;
        }
        Runnable back = () -> openItem(p, c.id, m);
        switch (slot) {
            case 10 -> ask(p, plugin.msg("prompt-price", "{item}", Util.name(m),
                    "{price}", Util.num(c.items.get(m))), back, raw -> {
                Double price = parsePrice(p, raw);
                if (price != null) {
                    plugin.shop().setItem(c, m, price);
                    p.sendMessage(plugin.msg("price-set", "{item}", Util.name(m), "{category}", c.id,
                            "{price}", Util.num(price)));
                }
                back.run();
            });
            case 12 -> {
                if (c.isPiece(m)) {
                    plugin.shop().setUnit(c, m, null);
                    p.sendMessage(plugin.msg("unit-stack", "{item}", Util.name(m), "{category}", c.id,
                            "{stack}", m.getMaxStackSize()));
                    later(back);
                } else {
                    askUnit(p, c, m, back);
                }
            }
            case 14 -> {
                if (c.isPiece(m)) askUnit(p, c, m, back);
            }
            case 16 -> {
                if (!shift) {
                    p.sendMessage(plugin.msg("panel-shift"));
                    return;
                }
                plugin.shop().removeItem(c, m);
                p.sendMessage(plugin.msg("item-removed", "{item}", Util.name(m), "{category}", c.id));
                later(() -> openCategory(p, c.id, 0));
            }
            case 19, 20, 21, 23, 24, 25 -> {
                double step = switch (slot) {
                    case 19 -> -10;
                    case 20 -> -1;
                    case 21 -> -0.1;
                    case 23 -> 0.1;
                    case 24 -> 1;
                    default -> 10;
                };
                if (shift) step *= 10;
                double price = Util.round2(Math.max(0, Math.min(Util.MAX_PRICE, c.items.get(m) + step)));
                plugin.shop().setItem(c, m, price);
                later(back); // ціну видно в іконках, окреме повідомлення в чат не потрібне
            }
            case 31 -> later(() -> openCategory(p, c.id, 0));
            default -> { }
        }
    }

    private void askUnit(Player p, Category c, Material m, Runnable back) {
        ask(p, plugin.msg("prompt-unit", "{item}", Util.name(m)), back, raw -> {
            if (raw.equalsIgnoreCase("stack")) {
                plugin.shop().setUnit(c, m, null);
                p.sendMessage(plugin.msg("unit-stack", "{item}", Util.name(m), "{category}", c.id,
                        "{stack}", m.getMaxStackSize()));
            } else {
                Integer n = parseInt(p, raw, 1, m.getMaxStackSize() * 36);
                if (n != null) {
                    plugin.shop().setUnit(c, m, n);
                    p.sendMessage(plugin.msg("unit-set", "{item}", Util.name(m), "{category}", c.id, "{amount}", n));
                }
            }
            back.run();
        });
    }

    // ───────────────────────── додавання предметів і розділів ─────────────────────────

    /** Предмет уже відомий (з руки або з інвентаря): питаємо лише ціну (або «кількість ціна»). */
    private void askAddItem(Player p, Category c, Material m) {
        Runnable back = () -> openCategory(p, c.id, Integer.MAX_VALUE);
        ask(p, plugin.msg("prompt-add-item", "{item}", Util.name(m), "{stack}", m.getMaxStackSize()), back, raw -> {
            applyAdd(p, c, m, raw.split("\\s+"));
            back.run();
        });
    }

    /** Предмета під рукою немає: пишемо «ПРЕДМЕТ [кількість] ціна». */
    private void askAddByName(Player p, Category c) {
        Runnable back = () -> openCategory(p, c.id, Integer.MAX_VALUE);
        ask(p, plugin.msg("prompt-add-name"), back, raw -> {
            String[] t = raw.split("\\s+");
            if (t.length < 2) {
                p.sendMessage(plugin.msg("invalid-number", "{value}", raw));
            } else {
                Material m = parseMaterial(p, t[0]);
                if (m != null) applyAdd(p, c, m, Arrays.copyOfRange(t, 1, t.length));
            }
            back.run();
        });
    }

    /** t = [ціна] (за повний стак) або [кількість, ціна]. */
    private void applyAdd(Player p, Category c, Material m, String[] t) {
        int max = m.getMaxStackSize();
        int amount;
        String rawPrice;
        if (t.length == 1) {
            amount = max;
            rawPrice = t[0];
        } else if (t.length == 2) {
            Integer n = parseInt(p, t[0], 1, max * 36);
            if (n == null) return;
            amount = n;
            rawPrice = t[1];
        } else {
            p.sendMessage(plugin.msg("invalid-number", "{value}", String.join(" ", t)));
            return;
        }
        Double price = parsePrice(p, rawPrice);
        if (price == null) return;

        plugin.shop().setItem(c, m, price, amount == max ? null : amount);
        p.sendMessage(plugin.msg("item-added", "{item}", Util.name(m), "{category}", c.id, "{amount}", amount,
                "{price}", plugin.currencies().format(c.currency, price)));
    }

    private void askNewCategory(Player p) {
        Runnable back = () -> openCategories(p, Integer.MAX_VALUE);
        ask(p, plugin.msg("prompt-category"), back, raw -> {
            String[] t = raw.split("\\s+", 3);
            String id = t[0].toLowerCase(Locale.ROOT);
            if (t.length < 2) {
                p.sendMessage(plugin.msg("invalid-item", "{item}", raw));
            } else if (!CATEGORY_ID.matcher(id).matches()) {
                p.sendMessage(plugin.msg("invalid-id", "{value}", t[0]));
            } else if (plugin.shop().get(id) != null) {
                p.sendMessage(plugin.msg("category-exists", "{category}", id));
            } else {
                Material icon = parseMaterial(p, t[1]);
                if (icon != null) {
                    plugin.shop().createCategory(id, t.length >= 3 ? t[2] : "&f" + id, icon);
                    p.sendMessage(plugin.msg("category-added", "{category}", id));
                    later(() -> openCategory(p, id, 0));
                    return;
                }
            }
            back.run();
        });
    }

    // ───────────────────────── мова, налаштування, лічильник ─────────────────────────

    private void clickLanguage(Player p, Holder h, int slot) {
        if (slot == 26) {
            later(() -> openMain(p));
            return;
        }
        String code = h.keys.get(slot);
        if (code == null || code.equals(plugin.lang().code())) return;

        plugin.getConfig().set("language", code);
        plugin.saveConfig();
        plugin.reloadAll();
        p.sendMessage(plugin.msg("language-changed", "{language}", languageName(code)));
        later(() -> openLanguage(p));
    }

    /** Записує значення в config.yml і одразу застосовує його. */
    private void setConfig(String path, Object value) {
        plugin.getConfig().set(path, value);
        plugin.saveConfig();
        plugin.reloadAll();
    }

    private void clickSettings(Player p, int slot, boolean right) {
        var cfg = plugin.getConfig();
        Runnable back = () -> openSettings(p);
        switch (slot) {
            case 10 -> ask(p, plugin.msg("prompt-sell-slot"), back, raw -> {
                Integer n = parseInt(p, raw, -1, 53);
                if (n != null) {
                    setConfig("gui.sell-all-slot", n);
                    p.sendMessage(plugin.msg("setting-saved"));
                }
                back.run();
            });
            case 11 -> {
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir() || !hand.getType().isItem()) {
                    p.sendMessage(plugin.msg("icon-hint"));
                    return;
                }
                setConfig("gui.sell-all-icon", hand.getType().name());
                p.sendMessage(plugin.msg("icon-set", "{value}", hand.getType().name()));
                later(back);
            }
            case 12 -> {
                int rows = cfg.getInt("gui.main-rows", 3) + (right ? -1 : 1);
                setConfig("gui.main-rows", Math.max(1, Math.min(6, rows)));
                later(back);
            }
            case 13 -> {
                setConfig("gui.filler", !cfg.getBoolean("gui.filler", true));
                later(back);
            }
            case 14 -> {
                setConfig("gui.show-full-stack", !cfg.getBoolean("gui.show-full-stack", true));
                later(back);
            }
            case 15 -> ask(p, plugin.msg("prompt-vault-name"), back, raw -> {
                setConfig("currencies.vault.name", raw.equals("-") ? "" : raw);
                p.sendMessage(plugin.msg("setting-saved"));
                back.run();
            });
            case 16 -> {
                setConfig("currencies.donate.enabled", !cfg.getBoolean("currencies.donate.enabled", false));
                later(back);
            }
            case 19 -> ask(p, plugin.msg("prompt-donate-name"), back, raw -> {
                setConfig("currencies.donate.name", raw.equals("-") ? "" : raw);
                p.sendMessage(plugin.msg("setting-saved"));
                back.run();
            });
            case 20 -> ask(p, plugin.msg("prompt-donate-command"), back, raw -> {
                String cmd = raw.startsWith("/") ? raw.substring(1).trim() : raw;
                setConfig("currencies.donate.command", cmd);
                p.sendMessage(plugin.msg("setting-saved"));
                if (!cmd.contains("{player}") || !cmd.contains("{amount}")) {
                    p.sendMessage(plugin.msg("donate-command-warning"));
                }
                back.run();
            });
            case 21 -> askText(p, "prefix", back);
            case 22 -> askText(p, "menu.main-title", back);
            case 23 -> askText(p, "menu.sell-all-title", back);
            case 24 -> ask(p, plugin.msg("prompt-any-text"), back, raw -> {
                String[] t = raw.split("\\s+", 2);
                if (t.length < 2) {
                    p.sendMessage(plugin.msg("text-key-unknown", "{key}", raw));
                } else if (!plugin.lang().has(t[0])) {
                    p.sendMessage(plugin.msg("text-key-unknown", "{key}", t[0]));
                } else {
                    saveText(p, t[0], t[1]);
                }
                back.run();
            });
            case 31 -> later(() -> openMain(p));
            default -> { }
        }
    }

    private void askText(Player p, String key, Runnable back) {
        ask(p, plugin.msg("prompt-text", "{key}", key, "{value}", plugin.lang().raw(key)), back, raw -> {
            saveText(p, key, raw);
            back.run();
        });
    }

    private void saveText(Player p, String key, String value) {
        if (plugin.lang().set(key, value)) p.sendMessage(plugin.msg("text-saved", "{key}", key));
        else p.sendMessage(plugin.msg("economy-error"));
    }

    private void clickStats(Player p, Holder h, int slot, boolean shift) {
        switch (slot) {
            case 45 -> {
                if (h.page > 0) later(() -> openStats(p, h.page - 1));
                return;
            }
            case 53 -> {
                later(() -> openStats(p, h.page + 1));
                return;
            }
            case 49 -> {
                later(() -> openMain(p));
                return;
            }
            default -> { }
        }
        Material m = h.mats.get(slot);
        if (m == null) return;

        long have = plugin.stats().get(m);
        if (have <= 0) {
            p.sendMessage(plugin.msg("take-empty", "{item}", Util.name(m)));
            later(() -> openStats(p, h.page));
            return;
        }
        long want = shift ? have : Math.min(have, m.getMaxStackSize());
        long limit = SellService.takeLimit(m);
        boolean limited = want > limit;
        if (limited) want = limit;
        long taken = plugin.stats().take(m, want);
        plugin.service().giveItems(p, m, taken);
        plugin.sales().log(String.format("TAKE %s took %dx %s from counter (left %d)",
                p.getName(), taken, m.name(), plugin.stats().get(m)));
        p.sendMessage(plugin.msg("take-ok",
                "{amount}", taken, "{item}", Util.name(m), "{left}", plugin.stats().get(m)));
        if (limited) p.sendMessage(plugin.msg("take-limited", "{stacks}", SellService.MAX_TAKE_STACKS));
        later(() -> openStats(p, h.page));
    }
}
