package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SellGUI implements Listener {
    private static final int PER_PAGE = 45;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_BACK = 49;
    private static final int SLOT_NEXT = 53;
    private static final int CONFIRM_SIZE = 27;
    private static final int SLOT_YES = 11;
    private static final int SLOT_INFO = 13;
    private static final int SLOT_NO = 15;

    private final SellShop plugin;

    public SellGUI(SellShop plugin) {
        this.plugin = plugin;
    }

    /** Маркер наших меню. category == null — головне меню. */
    public static class Holder implements InventoryHolder {
        public final String category;
        public final int page;
        /** true — меню підтвердження «Продати все». */
        public final boolean confirm;
        /** Відбиток плану, показаного в меню підтвердження: «Так» продає лише якщо нічого не змінилось. */
        public String planSignature;
        /** Слот кнопки «Продати все» в головному меню (-1 — немає). */
        public int sellAllSlot = -1;
        /** true — розділи не вмістились в одну сторінку, у головному меню є кнопки сторінок. */
        public boolean paged = false;
        public final Map<Integer, String> slotToCategory = new HashMap<>();
        /** Що саме було показано в слотах розділу в момент відкриття: продаємо те, що гравець бачив. */
        public final Map<Integer, Snap> items = new HashMap<>();
        private Inventory inventory;

        public Holder(String category, int page) {
            this(category, page, false);
        }

        public Holder(String category, int page, boolean confirm) {
            this.category = category;
            this.page = page;
            this.confirm = confirm;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        void setInventory(Inventory inv) {
            this.inventory = inv;
        }
    }

    // ───────────────────────── відкриття меню ─────────────────────────

    /** Знімок слота розділу: що й за якою ціною гравець бачив у момент відкриття меню. */
    public record Snap(Material material, double price, int unit, boolean piece) {}

    /** Виконати на наступному тіку: відкривати інші меню прямо всередині InventoryClickEvent ненадійно. */
    private void later(Runnable r) {
        Bukkit.getScheduler().runTask(plugin, r);
    }

    public void openMain(Player p) {
        openMain(p, 0);
    }

    /**
     * Головне меню. Розділи ніколи не відкидаються: якщо їх більше, ніж слотів, меню спершу росте до 6 рядків,
     * а коли й цього мало — з'являються сторінки.
     */
    public void openMain(Player p, int page) {
        FileConfiguration cfg = plugin.getConfig();
        int rows = Math.max(1, Math.min(6, cfg.getInt("gui.main-rows", 3)));
        int sellAllSlot = cfg.getInt("gui.sell-all-slot", 22);
        boolean hasSellAll = sellAllSlot >= 0;

        List<Category> cats = new ArrayList<>(plugin.shop().categories());
        int needed = cats.size() + (hasSellAll ? 1 : 0);
        boolean paged = needed > 54;
        int size;
        int pages = 1;
        if (paged) {
            size = 54;
            pages = (int) Math.ceil(cats.size() / (double) PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
        } else {
            rows = Math.max(rows, (int) Math.ceil(needed / 9.0));
            size = rows * 9;
            page = 0;
        }

        Holder holder = new Holder(null, page);
        holder.paged = paged;
        String title = plugin.lang().text("menu.main-title")
                + (paged ? Util.color(" &8(" + (page + 1) + "/" + pages + ")") : "");
        Inventory inv = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inv);

        if (cfg.getBoolean("gui.filler", true) || paged) {
            ItemStack pane = pane();
            for (int i = 0; i < size; i++) inv.setItem(i, pane);
        }

        Set<Integer> used = new HashSet<>();

        if (paged) {
            // 45 слотів під розділи, нижній ряд — навігація; «Продати все» стає в центр нижнього ряду
            int from = page * PER_PAGE;
            for (int i = from; i < Math.min(cats.size(), from + PER_PAGE); i++) {
                put(inv, holder, i - from, cats.get(i));
            }
            if (page > 0) inv.setItem(SLOT_PREV, named(Material.ARROW, plugin.lang().raw("menu.prev")));
            if (page < pages - 1) inv.setItem(SLOT_NEXT, named(Material.ARROW, plugin.lang().raw("menu.next")));
            if (hasSellAll) {
                holder.sellAllSlot = SLOT_BACK;
                inv.setItem(SLOT_BACK, sellAllButton(p));
            }
            p.openInventory(inv);
            return;
        }

        // кнопка «Продати все» (за замовчуванням — центр нижнього рядка, як у Hypixel Skyblock)
        if (hasSellAll) {
            if (sellAllSlot >= size) sellAllSlot = size - 1;
            holder.sellAllSlot = sellAllSlot;
            used.add(sellAllSlot);
            inv.setItem(sellAllSlot, sellAllButton(p));
        }

        List<Category> auto = new ArrayList<>();
        for (Category c : cats) {
            if (c.slot >= 0 && c.slot < size && !used.contains(c.slot)) {
                put(inv, holder, c.slot, c);
                used.add(c.slot);
            } else {
                auto.add(c);
            }
        }
        int next = 0;
        for (Category c : auto) {
            while (next < size && used.contains(next)) next++;
            if (next >= size) break; // недосяжно: size >= needed
            put(inv, holder, next, c);
            used.add(next);
        }

        p.openInventory(inv);
    }

    private ItemStack sellAllButton(Player p) {
        Material icon = Material.matchMaterial(plugin.getConfig().getString("gui.sell-all-icon", "CHEST"));
        if (icon == null || icon.isAir() || !icon.isItem()) icon = Material.CHEST;

        ItemStack it = new ItemStack(icon);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(plugin.lang().text("menu.sell-all-title"));
        List<String> lore = new ArrayList<>();
        List<SellService.Entry> plan = plugin.service().canSell(p) ? plugin.service().plan(p) : List.of();
        if (!plugin.service().canSell(p)) {
            lore.add(plugin.lang().text("menu.sell-all-creative"));
        } else if (plan.isEmpty()) {
            lore.add(plugin.lang().text("menu.sell-all-empty"));
        } else {
            lore.add(plugin.lang().text("menu.sell-all-kinds", "{kinds}", plan.size()));
            lore.addAll(sellLines(plan, 8));
            lore.add("");
            lore.add(plugin.lang().text("menu.sell-all-total", "{total}",
                    plugin.service().formatTotals(plugin.service().totals(plan))));
            lore.add("");
            lore.add(plugin.lang().text("menu.sell-all-click"));
        }
        meta.setLore(lore);
        Util.hideExtras(meta);
        it.setItemMeta(meta);
        return it;
    }

    /** Рядки «предмет ×кількість — виручка», найдорожчі зверху; зайве згортається в «...та ще N». */
    private List<String> sellLines(List<SellService.Entry> plan, int max) {
        List<SellService.Entry> sorted = new ArrayList<>(plan);
        sorted.sort(Comparator.comparingDouble((SellService.Entry e) -> e.money).reversed());
        List<String> out = new ArrayList<>();
        int shown = sorted.size() > max ? max - 1 : sorted.size();
        for (int i = 0; i < shown; i++) {
            SellService.Entry e = sorted.get(i);
            out.add(plugin.lang().text("confirm.list-line",
                    "{item}", Util.name(e.material),
                    "{amount}", e.pieces,
                    "{money}", plugin.currencies().format(e.category.currency, e.money)));
        }
        if (sorted.size() > shown) {
            out.add(plugin.lang().text("confirm.more", "{count}", sorted.size() - shown));
        }
        return out;
    }

    /** Меню підтвердження — один сундук (3 ряди): «Так», підсумок посередині і «Ні». */
    public void openConfirm(Player p) {
        openConfirm(p, 0);
    }

    /** @param mainPage сторінка головного меню, з якої натиснули «Продати все»: після підтвердження повертаємось на неї */
    public void openConfirm(Player p, int mainPage) {
        if (!plugin.service().canSell(p)) {
            p.sendMessage(plugin.msg("creative-denied"));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }
        List<SellService.Entry> plan = plugin.service().plan(p);
        if (plan.isEmpty()) {
            p.sendMessage(plugin.msg("sell-all-nothing"));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }

        Holder holder = new Holder(null, mainPage, true);
        holder.planSignature = plugin.service().signature(plan);
        Inventory inv = Bukkit.createInventory(holder, CONFIRM_SIZE, plugin.lang().text("confirm.title"));
        holder.setInventory(inv);

        ItemStack pane = pane();
        for (int i = 0; i < CONFIRM_SIZE; i++) inv.setItem(i, pane);

        String totalText = plugin.service().formatTotals(plugin.service().totals(plan));
        long pieces = 0;
        for (SellService.Entry e : plan) pieces += e.pieces;

        ItemStack yes = named(Material.LIME_CONCRETE, plugin.lang().raw("confirm.accept"));
        ItemMeta ym = yes.getItemMeta();
        ym.setLore(List.of(plugin.lang().text("confirm.accept-lore", "{total}", totalText)));
        yes.setItemMeta(ym);
        inv.setItem(SLOT_YES, yes);

        ItemStack info = named(Material.CHEST, plugin.lang().raw("confirm.info-title"));
        ItemMeta im = info.getItemMeta();
        List<String> il = new ArrayList<>();
        il.add(plugin.lang().text("confirm.info-kinds", "{kinds}", plan.size()));
        il.add(plugin.lang().text("confirm.info-pieces", "{amount}", pieces));
        il.add("");
        il.addAll(sellLines(plan, 20));
        il.add("");
        il.add(plugin.lang().text("confirm.info-total", "{total}", totalText));
        im.setLore(il);
        info.setItemMeta(im);
        inv.setItem(SLOT_INFO, info);

        ItemStack no = named(Material.RED_CONCRETE, plugin.lang().raw("confirm.decline"));
        ItemMeta nm = no.getItemMeta();
        nm.setLore(List.of(plugin.lang().text("confirm.decline-lore")));
        no.setItemMeta(nm);
        inv.setItem(SLOT_NO, no);

        p.openInventory(inv);
    }

    private void put(Inventory inv, Holder holder, int slot, Category c) {
        ItemStack it = new ItemStack(c.icon);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(c.title));
        List<String> lore = new ArrayList<>();
        lore.add(plugin.lang().text("menu.category-items", "{count}", c.items.size()));
        lore.add("");
        lore.add(plugin.lang().text("menu.click-open"));
        meta.setLore(lore);
        Util.hideExtras(meta);
        it.setItemMeta(meta);
        inv.setItem(slot, it);
        holder.slotToCategory.put(slot, c.id);
    }

    public void openCategory(Player p, Category c, int page) {
        int total = c.items.size();
        int pages = Math.max(1, (int) Math.ceil(total / (double) PER_PAGE));
        page = Math.max(0, Math.min(page, pages - 1));

        Holder holder = new Holder(c.id, page);
        String title = Util.color(c.title) + (pages > 1 ? Util.color(" &8(" + (page + 1) + "/" + pages + ")") : "");
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        ItemStack pane = pane();
        for (int i = PER_PAGE; i < 54; i++) inv.setItem(i, pane);

        refresh(p, inv, holder, c, page);

        if (page > 0) inv.setItem(SLOT_PREV, named(Material.ARROW, plugin.lang().raw("menu.prev")));
        if (page < pages - 1) inv.setItem(SLOT_NEXT, named(Material.ARROW, plugin.lang().raw("menu.next")));
        inv.setItem(SLOT_BACK, named(Material.BARRIER, plugin.lang().raw("menu.back")));

        p.openInventory(inv);
    }

    /** Перемальовує предмети (щоб оновити кількість в інвентарі в описі). */
    private void refresh(Player p, Inventory inv, Holder holder, Category c, int page) {
        List<Map.Entry<Material, Double>> list = new ArrayList<>(c.items.entrySet());
        holder.items.clear();
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= list.size()) {
                inv.setItem(i, null);
                continue;
            }
            Map.Entry<Material, Double> e = list.get(idx);
            Material m = e.getKey();
            holder.items.put(i, new Snap(m, e.getValue(), c.unit(m), c.isPiece(m)));
            inv.setItem(i, shopItem(p, c, m, e.getValue()));
        }
    }

    private ItemStack shopItem(Player p, Category c, Material m, double price) {
        int stack = c.unit(m);
        boolean piece = c.isPiece(m);
        boolean full = plugin.getConfig().getBoolean("gui.show-full-stack", true);
        ItemStack it = new ItemStack(m, full ? Math.min(stack, m.getMaxStackSize()) : 1);
        ItemMeta meta = it.getItemMeta();
        int have = plugin.service().count(p, m);
        int fullStacks = have / stack;
        double stackPrice = Util.round2(price);
        String id = c.currency;

        List<String> lore = new ArrayList<>();
        lore.add(plugin.lang().text(piece ? "item.price-piece" : "item.price-stack",
                "{amount}", stack, "{price}", plugin.currencies().format(id, stackPrice)));
        lore.add("");
        lore.add(plugin.lang().text("item.have", "{have}", have));
        lore.add(plugin.lang().text(piece ? "item.stacks-piece" : "item.stacks-stack",
                "{amount}", stack, "{count}", fullStacks));
        lore.add(plugin.lang().text("item.total", "{total}",
                plugin.currencies().format(id, Util.round2(stackPrice * fullStacks))));
        lore.add("");
        lore.add(piece ? plugin.lang().text("item.click-piece", "{amount}", stack) : plugin.lang().text("item.click-stack"));
        lore.add(plugin.lang().text("item.click-all"));
        meta.setLore(lore);
        Util.hideExtras(meta);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack pane() {
        return named(Material.GRAY_STAINED_GLASS_PANE, " ");
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(name));
        it.setItemMeta(meta);
        return it;
    }

    // ───────────────────────── події ─────────────────────────

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        // getHolder(false): не робити знімок блока (для сундуків на сервері це дорого)
        if (e.getInventory().getHolder(false) instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Holder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        // лише звичайні кліки (ЛКМ/ПКМ, з Shift або без): подвійний клік, цифри, Q, середня кнопка тощо ігноруємо
        ClickType type = e.getClick();
        if (type != ClickType.LEFT && type != ClickType.SHIFT_LEFT
                && type != ClickType.RIGHT && type != ClickType.SHIFT_RIGHT) return;

        int slot = e.getSlot();

        // меню підтвердження «Продати все»
        if (holder.confirm) {
            if (slot == SLOT_YES) {
                if (plugin.service().sellAll(p, holder.planSignature)) {
                    later(() -> openMain(p, holder.page)); // після продажу повертаємось у меню розділів, на ту саму сторінку
                } else {
                    later(() -> openConfirm(p, holder.page)); // план змінився: показуємо новий підсумок, гравець підтверджує знову
                }
            } else if (slot == SLOT_NO) {
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
                later(() -> openMain(p, holder.page));
            }
            return;
        }

        // головне меню
        if (holder.category == null) {
            if (holder.paged) {
                int mainPages = Math.max(1, (int) Math.ceil(plugin.shop().categories().size() / (double) PER_PAGE));
                if (slot == SLOT_PREV && holder.page > 0) {
                    later(() -> openMain(p, holder.page - 1));
                    return;
                }
                if (slot == SLOT_NEXT && holder.page < mainPages - 1) {
                    later(() -> openMain(p, holder.page + 1));
                    return;
                }
            }
            if (slot == holder.sellAllSlot) {
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
                later(() -> openConfirm(p, holder.page));
                return;
            }
            String cid = holder.slotToCategory.get(slot);
            if (cid == null) return;
            Category c = plugin.shop().get(cid);
            if (c == null) return;
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
            later(() -> openCategory(p, c, 0));
            return;
        }

        // меню розділу
        Category c = plugin.shop().get(holder.category);
        if (c == null) {
            p.closeInventory();
            return;
        }
        int pages = Math.max(1, (int) Math.ceil(c.items.size() / (double) PER_PAGE));

        if (slot == SLOT_BACK) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
            later(() -> openMain(p));
            return;
        }
        if (slot == SLOT_PREV && holder.page > 0) {
            later(() -> openCategory(p, c, holder.page - 1));
            return;
        }
        if (slot == SLOT_NEXT && holder.page < pages - 1) {
            later(() -> openCategory(p, c, holder.page + 1));
            return;
        }
        if (slot >= PER_PAGE) return;

        // Продаємо те, що гравець бачив у цьому слоті. Якщо адмін за цей час змінив список або ціну,
        // нічого не продаємо, а перемальовуємо розділ.
        Snap snap = holder.items.get(slot);
        if (snap == null) return;
        Material m = snap.material();
        Double now = c.items.get(m);
        if (now == null || Math.abs(now - snap.price()) > 1e-9
                || c.unit(m) != snap.unit() || c.isPiece(m) != snap.piece()) {
            p.sendMessage(plugin.msg("shop-changed"));
            later(() -> openCategory(p, c, holder.page));
            return;
        }

        plugin.service().sell(p, c, m, e.isShiftClick());
        refresh(p, e.getView().getTopInventory(), holder, c, holder.page);
    }
}
