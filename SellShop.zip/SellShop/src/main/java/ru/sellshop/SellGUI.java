package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SellGUI implements Listener {
    private static final int PER_PAGE = 45;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_BACK = 49;
    private static final int SLOT_NEXT = 53;
    private static final int SLOT_YES = 47;
    private static final int SLOT_INFO = 49;
    private static final int SLOT_NO = 51;

    private final SellShop plugin;

    public SellGUI(SellShop plugin) {
        this.plugin = plugin;
    }

    /** Маркер наших меню. category == null — головне меню. */
    public static class Holder implements InventoryHolder {
        public final String category;
        public final int page;
        /** true — меню підтвердження «Продати все». */
        public final boolean confirm;
        /** Слот кнопки «Продати все» в головному меню (-1 — немає). */
        public int sellAllSlot = -1;
        public final Map<Integer, String> slotToCategory = new HashMap<>();
        private Inventory inventory;

        public Holder(String category, int page) {
            this(category, page, false);
        }

        public Holder(String category, int page, boolean confirm) {
            this.category = category;
            this.page = page;
            this.confirm = confirm;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        void setInventory(Inventory inv) {
            this.inventory = inv;
        }
    }

    // ───────────────────────── відкриття меню ─────────────────────────

    public void openMain(Player p) {
        FileConfiguration cfg = plugin.getConfig();
        int rows = Math.max(1, Math.min(6, cfg.getInt("gui.main-rows", 3)));
        int size = rows * 9;

        Holder holder = new Holder(null, 0);
        Inventory inv = Bukkit.createInventory(holder, size, plugin.lang().text("menu.main-title"));
        holder.setInventory(inv);

        if (cfg.getBoolean("gui.filler", true)) {
            ItemStack pane = pane();
            for (int i = 0; i < size; i++) inv.setItem(i, pane);
        }

        Set<Integer> used = new HashSet<>();

        // кнопка «Продати все» (за замовчуванням — початок другого рядка)
        int sellAllSlot = cfg.getInt("gui.sell-all-slot", 9);
        if (sellAllSlot >= 0) {
            if (sellAllSlot >= size) sellAllSlot = size - 1;
            holder.sellAllSlot = sellAllSlot;
            used.add(sellAllSlot);
            inv.setItem(sellAllSlot, sellAllButton(p));
        }

        List<Category> auto = new ArrayList<>();
        for (Category c : plugin.shop().categories()) {
            if (c.slot >= 0 && c.slot < size && !used.contains(c.slot)) {
                put(inv, holder, c.slot, c);
                used.add(c.slot);
            } else {
                auto.add(c);
            }
        }
        int next = 0;
        for (Category c : auto) {
            while (next < size && used.contains(next)) next++;
            if (next >= size) break;
            put(inv, holder, next, c);
            used.add(next);
        }

        p.openInventory(inv);
    }

    private ItemStack sellAllButton(Player p) {
        Material icon = Material.matchMaterial(plugin.getConfig().getString("gui.sell-all-icon", "EMERALD"));
        if (icon == null || icon.isAir() || !icon.isItem()) icon = Material.EMERALD;

        ItemStack it = new ItemStack(icon);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(plugin.lang().text("menu.sell-all-title"));
        List<String> lore = new ArrayList<>();
        List<SellService.Entry> plan = plugin.service().plan(p);
        if (plan.isEmpty()) {
            lore.add(plugin.lang().text("menu.sell-all-empty"));
        } else {
            lore.add(plugin.lang().text("menu.sell-all-kinds", "{kinds}", plan.size()));
            lore.add(plugin.lang().text("menu.sell-all-total", "{total}",
                    plugin.service().formatTotals(plugin.service().totals(plan))));
            lore.add("");
            lore.add(plugin.lang().text("menu.sell-all-click"));
        }
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    /** Меню підтвердження: показує, що буде продано, загальну суму і кнопки «Так» / «Ні». */
    public void openConfirm(Player p) {
        List<SellService.Entry> plan = plugin.service().plan(p);
        if (plan.isEmpty()) {
            p.sendMessage(plugin.msg("sell-all-nothing"));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }

        Holder holder = new Holder(null, 0, true);
        Inventory inv = Bukkit.createInventory(holder, 54, plugin.lang().text("confirm.title"));
        holder.setInventory(inv);

        ItemStack pane = pane();
        for (int i = PER_PAGE; i < 54; i++) inv.setItem(i, pane);

        List<SellService.Entry> sorted = new ArrayList<>(plan);
        sorted.sort(Comparator.comparingDouble((SellService.Entry e) -> e.money).reversed());
        int shown = sorted.size() > PER_PAGE ? PER_PAGE - 1 : sorted.size();
        for (int i = 0; i < shown; i++) {
            SellService.Entry e = sorted.get(i);
            ItemStack it = new ItemStack(e.material, Math.max(1, Math.min(e.pieces, e.material.getMaxStackSize())));
            ItemMeta meta = it.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(plugin.lang().text("confirm.item-amount", "{amount}", e.pieces));
            lore.add(plugin.lang().text("confirm.item-money", "{money}",
                    plugin.currencies().format(e.category.currency, e.money)));
            meta.setLore(lore);
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }
        if (sorted.size() > shown) {
            inv.setItem(PER_PAGE - 1, named(Material.PAPER,
                    plugin.lang().raw("confirm.more", "{count}", sorted.size() - shown)));
        }

        Map<String, Double> totals = plugin.service().totals(plan);
        String totalText = plugin.service().formatTotals(totals);
        long pieces = 0;
        for (SellService.Entry e : plan) pieces += e.pieces;

        ItemStack yes = named(Material.LIME_CONCRETE, plugin.lang().raw("confirm.accept"));
        ItemMeta ym = yes.getItemMeta();
        ym.setLore(List.of(plugin.lang().text("confirm.accept-lore", "{total}", totalText)));
        yes.setItemMeta(ym);
        inv.setItem(SLOT_YES, yes);

        ItemStack info = named(Material.GOLD_INGOT, plugin.lang().raw("confirm.info-title"));
        ItemMeta im = info.getItemMeta();
        List<String> il = new ArrayList<>();
        il.add(plugin.lang().text("confirm.info-kinds", "{kinds}", plan.size()));
        il.add(plugin.lang().text("confirm.info-pieces", "{amount}", pieces));
        il.add(plugin.lang().text("confirm.info-total", "{total}", totalText));
        im.setLore(il);
        info.setItemMeta(im);
        inv.setItem(SLOT_INFO, info);

        ItemStack no = named(Material.RED_CONCRETE, plugin.lang().raw("confirm.decline"));
        ItemMeta nm = no.getItemMeta();
        nm.setLore(List.of(plugin.lang().text("confirm.decline-lore")));
        no.setItemMeta(nm);
        inv.setItem(SLOT_NO, no);

        p.openInventory(inv);
    }

    private void put(Inventory inv, Holder holder, int slot, Category c) {
        ItemStack it = new ItemStack(c.icon);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(c.title));
        List<String> lore = new ArrayList<>();
        lore.add(plugin.lang().text("menu.category-items", "{count}", c.items.size()));
        lore.add("");
        lore.add(plugin.lang().text("menu.click-open"));
        meta.setLore(lore);
        it.setItemMeta(meta);
        inv.setItem(slot, it);
        holder.slotToCategory.put(slot, c.id);
    }

    public void openCategory(Player p, Category c, int page) {
        int total = c.items.size();
        int pages = Math.max(1, (int) Math.ceil(total / (double) PER_PAGE));
        page = Math.max(0, Math.min(page, pages - 1));

        Holder holder = new Holder(c.id, page);
        String title = Util.color(c.title) + (pages > 1 ? Util.color(" &8(" + (page + 1) + "/" + pages + ")") : "");
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        ItemStack pane = pane();
        for (int i = PER_PAGE; i < 54; i++) inv.setItem(i, pane);

        refresh(p, inv, c, page);

        if (page > 0) inv.setItem(SLOT_PREV, named(Material.ARROW, plugin.lang().raw("menu.prev")));
        if (page < pages - 1) inv.setItem(SLOT_NEXT, named(Material.ARROW, plugin.lang().raw("menu.next")));
        inv.setItem(SLOT_BACK, named(Material.BARRIER, plugin.lang().raw("menu.back")));

        p.openInventory(inv);
    }

    /** Перемальовує предмети (щоб оновити кількість в інвентарі в описі). */
    private void refresh(Player p, Inventory inv, Category c, int page) {
        List<Map.Entry<Material, Double>> list = new ArrayList<>(c.items.entrySet());
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= list.size()) {
                inv.setItem(i, null);
                continue;
            }
            Map.Entry<Material, Double> e = list.get(idx);
            inv.setItem(i, shopItem(p, c, e.getKey(), e.getValue()));
        }
    }

    private ItemStack shopItem(Player p, Category c, Material m, double price) {
        int stack = c.unit(m);
        boolean piece = c.isPiece(m);
        boolean full = plugin.getConfig().getBoolean("gui.show-full-stack", true);
        ItemStack it = new ItemStack(m, full ? Math.min(stack, m.getMaxStackSize()) : 1);
        ItemMeta meta = it.getItemMeta();
        int have = plugin.service().count(p, m);
        int fullStacks = have / stack;
        double stackPrice = Util.round2(price);
        String id = c.currency;

        List<String> lore = new ArrayList<>();
        lore.add(plugin.lang().text(piece ? "item.price-piece" : "item.price-stack",
                "{amount}", stack, "{price}", plugin.currencies().format(id, stackPrice)));
        lore.add("");
        lore.add(plugin.lang().text("item.have", "{have}", have));
        lore.add(plugin.lang().text(piece ? "item.stacks-piece" : "item.stacks-stack",
                "{amount}", stack, "{count}", fullStacks));
        lore.add(plugin.lang().text("item.total", "{total}",
                plugin.currencies().format(id, Util.round2(stackPrice * fullStacks))));
        lore.add("");
        lore.add(piece ? plugin.lang().text("item.click-piece", "{amount}", stack) : plugin.lang().text("item.click-stack"));
        lore.add(plugin.lang().text("item.click-all"));
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack pane() {
        return named(Material.GRAY_STAINED_GLASS_PANE, " ");
    }

    private ItemStack named(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Util.color(name));
        it.setItemMeta(meta);
        return it;
    }

    // ───────────────────────── події ─────────────────────────

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        ClickType type = e.getClick();
        if (!type.isLeftClick() && !type.isRightClick()) return;

        int slot = e.getSlot();

        // меню підтвердження «Продати все»
        if (holder.confirm) {
            if (slot == SLOT_YES) {
                p.closeInventory();
                plugin.service().sellAll(p);
            } else if (slot == SLOT_NO) {
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
                openMain(p);
            }
            return;
        }

        // головне меню
        if (holder.category == null) {
            if (slot == holder.sellAllSlot) {
                p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
                openConfirm(p);
                return;
            }
            String cid = holder.slotToCategory.get(slot);
            if (cid == null) return;
            Category c = plugin.shop().get(cid);
            if (c == null) return;
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
            openCategory(p, c, 0);
            return;
        }

        // меню розділу
        Category c = plugin.shop().get(holder.category);
        if (c == null) {
            p.closeInventory();
            return;
        }
        int pages = Math.max(1, (int) Math.ceil(c.items.size() / (double) PER_PAGE));

        if (slot == SLOT_BACK) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
            openMain(p);
            return;
        }
        if (slot == SLOT_PREV && holder.page > 0) {
            openCategory(p, c, holder.page - 1);
            return;
        }
        if (slot == SLOT_NEXT && holder.page < pages - 1) {
            openCategory(p, c, holder.page + 1);
            return;
        }
        if (slot >= PER_PAGE) return;

        List<Map.Entry<Material, Double>> list = new ArrayList<>(c.items.entrySet());
        int idx = holder.page * PER_PAGE + slot;
        if (idx >= list.size()) return;

        Material m = list.get(idx).getKey();
        plugin.service().sell(p, c, m, e.isShiftClick());
        refresh(p, e.getView().getTopInventory(), c, holder.page);
    }
}
