package ru.sellshop;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Util {
    private Util() {}

    /** Верхня межа ціни: далі Util.round2 і сума за багато стаків починають втрачати точність. */
    public static final double MAX_PRICE = 1_000_000_000d;

    /** Ціна без NaN, мінусу й нескінченності, не вище {@link #MAX_PRICE}. */
    public static double cleanPrice(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d) || d < 0) return 0.0;
        return Math.min(d, MAX_PRICE);
    }

    /** Ховає атрибути та додаткові підказки (мечі, інструменти, зілля) в іконках меню. */
    public static void hideExtras(ItemMeta meta) {
        if (meta == null) return;
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
    }

    /** Запис YAML через тимчасовий файл: збій посеред запису не псує вже наявний файл. */
    public static void saveAtomic(YamlConfiguration y, File target) throws IOException {
        File tmp = new File(target.getParentFile(), target.getName() + ".tmp");
        y.save(tmp);
        try {
            Files.move(tmp.toPath(), target.toPath(),
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    public static String num(double d) {
        return new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(Locale.US)).format(d);
    }

    public static double round2(double d) {
        return Math.round(d * 100.0) / 100.0;
    }

    /** STONE_BRICKS -> Stone Bricks */
    public static String name(Material m) {
        String[] parts = m.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }
}
