package ru.sellshop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.regex.Pattern;

/** Донатна валюта: видача через консольну команду (PlayerPoints, власний плагін тощо). */
public class CommandCurrency implements Currency {
    /** Нік у консольній команді: лише безпечні символи ('.' — префікс Bedrock/Floodgate). */
    private static final Pattern SAFE_NAME = Pattern.compile("^[A-Za-z0-9_.]{1,20}$");

    private final String name;
    private final String command;
    private final String format;
    /** true — у команду підставляється лише ціле число (PlayerPoints та подібні не приймають дробові). */
    private final boolean wholeAmounts;

    public CommandCurrency(String name, String command, String format, boolean wholeAmounts) {
        this.name = name;
        this.command = command;
        this.format = format;
        this.wholeAmounts = wholeAmounts;
    }

    @Override
    public double normalize(double amount) {
        return wholeAmounts ? Math.floor(amount + 1e-9) : amount;
    }

    @Override
    public boolean give(Player player, double amount) {
        String playerName = player.getName();
        if (!SAFE_NAME.matcher(playerName).matches()) {
            Bukkit.getLogger().warning("[SellShop] Donate payout refused: unsafe player name \"" + playerName + "\"");
            return false;
        }
        String cmd = command.trim();
        while (cmd.startsWith("/")) cmd = cmd.substring(1).trim(); // dispatchCommand не приймає ведучий /
        cmd = cmd.replace("{player}", playerName).replace("{amount}", Util.num(normalize(amount)));
        if (cmd.isEmpty()) return false;

        boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        if (ok) return true;

        // Багато плагінів видають валюту й усе одно повертають false. Якщо повернути предмети тут, гравець отримає
        // і валюту, і предмети. Тому «false» вважаємо провалом лише коли такої команди справді немає.
        String label = cmd.split("\\s+", 2)[0];
        if (Bukkit.getCommandMap().getCommand(label) == null) {
            Bukkit.getLogger().warning("[SellShop] Donate command not found: /" + label);
            return false;
        }
        Bukkit.getLogger().warning("[SellShop] Donate command \"" + label
                + "\" returned false, but it exists; the payout is treated as successful.");
        return true;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String format(double amount) {
        return format.replace("{name}", name).replace("{amount}", Util.num(normalize(amount)));
    }
}
