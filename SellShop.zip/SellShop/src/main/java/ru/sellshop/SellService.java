package ru.sellshop;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Логіка продажу: списання предметів, видача грошей, статистика, лог. Продаж іде повними стаками або наборами по N штук. */
public class SellService {
    private final SellShop plugin;

    public SellService(SellShop plugin) {
        this.plugin = plugin;
    }

    /** Предмет без імені/зачарувань тощо — продаються лише такі. */
    private static boolean isPlain(ItemStack it) {
        return it != null && !it.hasItemMeta();
    }

    public int count(Player p, Material m) {
        int n = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && it.getType() == m && isPlain(it)) n += it.getAmount();
        }
        return n;
    }

    private int remove(Player p, Material m, int limit) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getStorageContents();
        int left = limit;
        int removed = 0;
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack it = contents[i];
            if (it == null || it.getType() != m || !isPlain(it)) continue;
            int take = Math.min(left, it.getAmount());
            removed += take;
            left -= take;
            if (take >= it.getAmount()) contents[i] = null;
            else it.setAmount(it.getAmount() - take);
        }
        if (removed > 0) inv.setStorageContents(contents);
        return removed;
    }

    /** Повернути предмети гравцю (залишок падає на підлогу). */
    public void giveItems(Player p, Material m, long amount) {
        long rest = amount;
        int max = m.getMaxStackSize();
        while (rest > 0) {
            int n = (int) Math.min(rest, max);
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, n));
            Location loc = p.getLocation();
            for (ItemStack s : left.values()) {
                p.getWorld().dropItemNaturally(loc, s);
            }
            rest -= n;
        }
    }

    /**
     * Предмет продається або повними стаками, або наборами по N штук (див. {@link Category#unit}).
     *
     * @param all false — продати один стак/набір, true — продати все, що вистачає в інвентарі
     */
    public void sell(Player p, Category c, Material m, boolean all) {
        Double price = c.items.get(m);
        if (price == null) return;

        Currency currency = plugin.currencies().get(c.currency);
        if (currency == null) {
            p.sendMessage(plugin.msg("currency-unavailable"));
            return;
        }

        int stackSize = c.unit(m);
        int fullStacks = count(p, m) / stackSize;
        if (fullStacks <= 0) {
            p.sendMessage(plugin.msg(c.isPiece(m) ? "not-enough-for-amount" : "not-enough-for-stack",
                    "{item}", Util.name(m),
                    "{stack}", stackSize));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }

        int limit = (all ? fullStacks : 1) * stackSize;
        int removed = remove(p, m, limit);
        if (removed <= 0) {
            p.sendMessage(plugin.msg("nothing-to-sell", "{item}", Util.name(m)));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }

        int stacksSold = removed / stackSize;
        double total = Util.round2(price * stacksSold);
        if (!currency.give(p, total)) {
            giveItems(p, m, removed);
            p.sendMessage(plugin.msg("economy-error"));
            return;
        }

        plugin.stats().add(m, removed);
        plugin.sales().log(String.format("SELL %s sold %dx %s for %s (%s, category=%s, mode=%s)",
                p.getName(), removed, m.name(), Util.num(total), c.currency, c.id, all ? "all" : "stack"));

        p.sendMessage(plugin.msg("sold",
                "{amount}", removed,
                "{item}", Util.name(m),
                "{money}", currency.format(total),
                "{currency}", currency.name(),
                "{value}", Util.num(total),
                "{stacks}", stacksSold));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
    }

    // ───────────────────────── «Продати все» ─────────────────────────

    /** Один рядок плану масового продажу: що саме і за скільки буде продано. */
    public static class Entry {
        public final Category category;
        public final Material material;
        public final int stacks;
        public final int pieces;
        public final double money;

        Entry(Category category, Material material, int stacks, int pieces, double money) {
            this.category = category;
            this.material = material;
            this.stacks = stacks;
            this.pieces = pieces;
            this.money = money;
        }
    }

    /**
     * Рахує все, що гравець може продати прямо зараз, по всіх розділах одразу.
     * Якщо той самий предмет є в кількох розділах, він не рахується двічі.
     */
    public List<Entry> plan(Player p) {
        List<Entry> res = new ArrayList<>();
        Map<Material, Integer> have = new HashMap<>();
        Map<Material, Integer> claimed = new HashMap<>();
        for (Category c : plugin.shop().categories()) {
            if (plugin.currencies().get(c.currency) == null) continue;
            for (Map.Entry<Material, Double> e : c.items.entrySet()) {
                Material m = e.getKey();
                int unit = c.unit(m);
                int free = have.computeIfAbsent(m, k -> count(p, k)) - claimed.getOrDefault(m, 0);
                int stacks = free / unit;
                if (stacks <= 0) continue;
                claimed.merge(m, stacks * unit, Integer::sum);
                res.add(new Entry(c, m, stacks, stacks * unit, Util.round2(e.getValue() * stacks)));
            }
        }
        return res;
    }

    /** Загальна виручка за планом, окремо по кожній валюті (id валюти -> сума). */
    public Map<String, Double> totals(List<Entry> plan) {
        Map<String, Double> t = new LinkedHashMap<>();
        for (Entry e : plan) t.merge(e.category.currency, e.money, Double::sum);
        t.replaceAll((k, v) -> Util.round2(v));
        return t;
    }

    /** "Дзеньки х10, донат-монет х2" */
    public String formatTotals(Map<String, Double> totals) {
        List<String> parts = new ArrayList<>();
        for (Map.Entry<String, Double> e : totals.entrySet()) {
            parts.add(plugin.currencies().format(e.getKey(), e.getValue()));
        }
        return String.join(", ", parts);
    }

    /** Продає все з плану за один раз. Викликається після підтвердження в меню. */
    public void sellAll(Player p) {
        List<Entry> plan = plan(p);
        if (plan.isEmpty()) {
            p.sendMessage(plugin.msg("sell-all-nothing"));
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.7f, 1f);
            return;
        }

        // 1) забираємо предмети, групуючи по валюті
        Map<String, List<Entry>> byCurrency = new LinkedHashMap<>();
        Map<String, Map<Material, Integer>> removedByCurrency = new LinkedHashMap<>();
        Map<String, Double> totals = new LinkedHashMap<>();
        for (Entry e : plan) {
            int removed = remove(p, e.material, e.pieces);
            if (removed <= 0) continue;
            int unit = e.category.unit(e.material);
            int stacksSold = removed / unit;
            int extra = removed - stacksSold * unit;
            if (extra > 0) giveItems(p, e.material, extra);
            if (stacksSold <= 0) continue;
            int sold = stacksSold * unit;
            double money = Util.round2(e.category.items.get(e.material) * stacksSold);

            String cur = e.category.currency;
            byCurrency.computeIfAbsent(cur, k -> new ArrayList<>())
                    .add(new Entry(e.category, e.material, stacksSold, sold, money));
            removedByCurrency.computeIfAbsent(cur, k -> new LinkedHashMap<>()).merge(e.material, sold, Integer::sum);
            totals.merge(cur, money, Double::sum);
        }

        // 2) платимо по кожній валюті один раз; якщо не вийшло — повертаємо предмети цієї валюти
        Map<String, Double> paid = new LinkedHashMap<>();
        int kinds = 0;
        long pieces = 0;
        boolean failed = false;
        for (Map.Entry<String, List<Entry>> ce : byCurrency.entrySet()) {
            String cur = ce.getKey();
            Currency currency = plugin.currencies().get(cur);
            double total = Util.round2(totals.get(cur));
            if (currency == null || !currency.give(p, total)) {
                for (Map.Entry<Material, Integer> r : removedByCurrency.get(cur).entrySet()) {
                    giveItems(p, r.getKey(), r.getValue());
                }
                failed = true;
                continue;
            }
            paid.put(cur, total);
            for (Entry e : ce.getValue()) {
                kinds++;
                pieces += e.pieces;
                plugin.stats().add(e.material, e.pieces);
                plugin.sales().log(String.format("SELL %s sold %dx %s for %s (%s, category=%s, mode=sellall)",
                        p.getName(), e.pieces, e.material.name(), Util.num(e.money), cur, e.category.id));
            }
        }

        if (failed) p.sendMessage(plugin.msg("economy-error"));
        if (paid.isEmpty()) return;

        p.sendMessage(plugin.msg("sold-all",
                "{kinds}", kinds,
                "{amount}", pieces,
                "{money}", formatTotals(paid)));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
    }
}
