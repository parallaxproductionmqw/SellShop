package ru.sellshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Зберігає розділи та ціни, читає/пише shop.yml. */
public class ShopManager {
    private final SellShop plugin;
    private final File file;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    /**
     * Документ, який ми прочитали з shop.yml. Зберігаємо ним, а не пишемо з нуля, тому коментарі
     * та невідомі ключі, які адмін дописав руками, не пропадають.
     */
    private YamlConfiguration doc = new YamlConfiguration();
    /**
     * true — останнє читання shop.yml не вдалося (синтаксична помилка). Поки файл не виправлено і не
     * перезавантажено, save() нічого не пише, щоб не перезаписати файл адміна порожньою заготовкою.
     */
    private boolean saveBlocked = false;

    private static final List<String> HEADER_UK = List.of(
            "Розділи та ціни. Ціна вказується за 1 ПОВНИЙ СТАК предмета (наприклад, STONE: 64.0 = 64 монети за стак із 64 шт.).",
            "Для продажу наборами по N штук:  ПРЕДМЕТ: { mode: piece, amount: 24, price: 1.0 }",
            "Можна правити руками, командами /sa add | put | price | unit | remove або з адмін-панелі (/sa).");
    private static final List<String> HEADER_EN = List.of(
            "Categories and prices. The price is for ONE FULL STACK of the item (for example STONE: 64.0 = 64 coins for a stack of 64).",
            "For selling in bundles of N pieces use:  ITEM: { mode: piece, amount: 24, price: 1.0 }",
            "You can edit by hand, with the commands /sa add | put | price | unit | remove, or in the admin panel (/sa).");

    public ShopManager(SellShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "shop.yml");
    }

    /**
     * Читає shop.yml. Повертає false, якщо файл зіпсований: тоді лишаються попередні дані в пам'яті,
     * битий файл копіюється в shop.yml.broken, а save() блокується до наступного вдалого читання.
     */
    public synchronized boolean load() {
        YamlConfiguration y = new YamlConfiguration();
        if (file.exists()) {
            try {
                y.load(file);
            } catch (IOException | InvalidConfigurationException ex) {
                saveBlocked = true;
                backupBroken();
                plugin.getLogger().severe(plugin.lang().raw("log.shop-load-failed", "{error}", String.valueOf(ex.getMessage())));
                return false;
            }
        }
        saveBlocked = false;
        categories.clear();
        doc = y;
        ConfigurationSection root = y.getConfigurationSection("categories");
        if (root == null) return true;

        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;

            Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
            if (icon == null || !icon.isItem()) icon = Material.CHEST;

            Category c = new Category(
                    id.toLowerCase(Locale.ROOT),
                    s.getString("title", "&f" + id),
                    icon,
                    s.getInt("slot", -1),
                    s.getString("currency", "vault"));

            ConfigurationSection items = s.getConfigurationSection("items");
            if (items != null) {
                for (String key : items.getKeys(false)) {
                    Material m = Material.matchMaterial(key);
                    if (m == null || !m.isItem() || m.isAir()) {
                        plugin.getLogger().warning(plugin.lang().raw("log.unknown-item", "{item}", key, "{category}", id));
                        continue;
                    }
                    if (items.isConfigurationSection(key)) {
                        // новий формат: mode / amount / price
                        ConfigurationSection is = items.getConfigurationSection(key);
                        c.items.put(m, loadPrice(is.getDouble("price", 0.0), m, id));
                        String mode = is.getString("mode", "stack");
                        if (mode.equalsIgnoreCase("piece")) {
                            int amount = is.getInt("amount", 1);
                            if (amount < 1) amount = 1;
                            c.units.put(m, amount);
                        }
                    } else {
                        // старий формат: просто число = ціна за повний стак
                        c.items.put(m, loadPrice(items.getDouble(key), m, id));
                    }
                }
            }
            categories.put(c.id, c);
        }
        return true;
    }

    /** Копія битого shop.yml поруч із ним, щоб адмін міг знайти помилку й нічого не втратив. */
    private void backupBroken() {
        try {
            Files.copy(file.toPath(), new File(file.getParentFile(), "shop.yml.broken").toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            plugin.getLogger().warning("Cannot create shop.yml.broken: " + ex.getMessage());
        }
    }

    /** Ціна з shop.yml: некоректна або нульова ціна означає «не продається», про це пишемо в лог. */
    private double loadPrice(double raw, Material m, String categoryId) {
        double price = cleanPrice(raw);
        if (price <= 0) {
            plugin.getLogger().warning(plugin.lang().raw("log.zero-price", "{item}", m.name(), "{category}", categoryId));
        }
        return price;
    }

    /** Захист від ручних помилок у shop.yml: від'ємна, NaN або нескінченна ціна стає 0, надто велика — обрізається. */
    private static double cleanPrice(double d) {
        return Util.cleanPrice(d);
    }

    public synchronized void save() {
        if (saveBlocked) {
            plugin.getLogger().warning(plugin.lang().raw("log.shop-save-blocked"));
            return;
        }
        ConfigurationSection root = doc.getConfigurationSection("categories");
        if (root == null) root = doc.createSection("categories");

        // розділи, яких більше немає
        for (String key : new ArrayList<>(root.getKeys(false))) {
            if (!categories.containsKey(key.toLowerCase(Locale.ROOT))) root.set(key, null);
        }

        for (Category c : categories.values()) {
            String key = existingKey(root, c.id);
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) s = root.createSection(key);
            s.set("title", c.title);
            s.set("icon", c.icon.name());
            s.set("slot", c.slot);
            s.set("currency", c.currency);

            ConfigurationSection items = s.getConfigurationSection("items");
            if (items == null) items = s.createSection("items");

            // видалені предмети (ключі, які ми не розпізнали, не чіпаємо)
            for (String k : new ArrayList<>(items.getKeys(false))) {
                Material m = Material.matchMaterial(k);
                if (m != null && !c.items.containsKey(m)) items.set(k, null);
            }

            for (Map.Entry<Material, Double> e : c.items.entrySet()) {
                Material m = e.getKey();
                String ik = existingItemKey(items, m);
                Integer unit = c.units.get(m);
                ConfigurationSection is = items.getConfigurationSection(ik);
                if (unit != null) {
                    if (is == null) is = items.createSection(ik);
                    is.set("mode", "piece");
                    is.set("amount", unit);
                    is.set("price", e.getValue());
                } else if (is != null) {
                    is.set("mode", "stack");
                    is.set("amount", null);
                    is.set("price", e.getValue());
                } else {
                    items.set(ik, e.getValue());
                }
            }
        }

        refreshHeader();
        try {
            Util.saveAtomic(doc, file);
        } catch (IOException ex) {
            plugin.getLogger().severe(plugin.lang().raw("log.shop-save-failed", "{error}", ex.getMessage()));
        }
    }

    private static String existingKey(ConfigurationSection sec, String id) {
        for (String k : sec.getKeys(false)) {
            if (k.equalsIgnoreCase(id)) return k;
        }
        return id;
    }

    private static String existingItemKey(ConfigurationSection sec, Material m) {
        for (String k : sec.getKeys(false)) {
            if (Material.matchMaterial(k) == m) return k;
        }
        return m.name();
    }

    /** Старий заголовок (від версій до 1.4.1) замінюємо на актуальний; власні коментарі адміна не чіпаємо. */
    private void refreshHeader() {
        List<String> fresh = "en".equals(plugin.lang().code()) ? HEADER_EN : HEADER_UK;
        List<String> comments = doc.getComments("categories");
        if (isOldHeader(comments)) doc.setComments("categories", fresh);
        List<String> header = doc.options().getHeader();
        if (isOldHeader(header)) doc.options().setHeader(fresh);
    }

    private static boolean isOldHeader(List<String> lines) {
        if (lines == null) return false;
        for (String l : lines) {
            if (l != null && (l.contains("лише повними стаками") || l.contains("add | price | remove"))) return true;
        }
        return false;
    }

    /** true — shop.yml не вдалося прочитати, тому зміни не зберігаються (див. {@link #load()}). */
    public synchronized boolean isSaveBlocked() {
        return saveBlocked;
    }

    public synchronized Collection<Category> categories() {
        return categories.values();
    }

    public synchronized Category get(String id) {
        return id == null ? null : categories.get(id.toLowerCase(Locale.ROOT));
    }

    public synchronized Category createCategory(String id, String title, Material icon) {
        Category c = new Category(id.toLowerCase(Locale.ROOT), title, icon, -1, "vault");
        categories.put(c.id, c);
        save();
        return c;
    }

    public synchronized boolean removeCategory(String id) {
        boolean removed = categories.remove(id.toLowerCase(Locale.ROOT)) != null;
        if (removed) save();
        return removed;
    }

    /** Додає/оновлює предмет. Режим (стак/поштучно) лишається як був. */
    public synchronized void setItem(Category c, Material m, double price) {
        c.items.put(m, price);
        save();
    }

    /** Додає предмет разом із кількістю: unit == null — продаж повним стаком, інакше набори по unit штук. */
    public synchronized void setItem(Category c, Material m, double price, Integer unit) {
        c.items.put(m, price);
        if (unit == null) c.units.remove(m);
        else c.units.put(m, unit);
        save();
    }

    /** Змінює режим продажу: unit == null — повні стаки, інакше набори по unit штук. */
    public synchronized void setUnit(Category c, Material m, Integer unit) {
        if (unit == null) c.units.remove(m);
        else c.units.put(m, unit);
        save();
    }

    public synchronized boolean removeItem(Category c, Material m) {
        c.units.remove(m);
        boolean removed = c.items.remove(m) != null;
        if (removed) save();
        return removed;
    }
}
