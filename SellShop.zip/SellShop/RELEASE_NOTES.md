# SellShop 1.4.1-hotfix

A hotfix for 1.4.1. All other changes of 1.4.1 are listed in `CHANGELOG.md`.

## Restored

* **After "Sell everything" you return to the categories menu**, on the page you started from (before, always the first page).

## Security and stability

* **A typo in `shop.yml` can no longer erase your shop.** If the file cannot be read, the previous data is kept, a copy is saved as `shop.yml.broken`, and nothing is written until you fix the file and run `/sa reload`.
* **The counter can no longer flood the server with items.** `/sa take` and Shift+click give at most 36 stacks at once; the rest stays in the counter. Before, taking a huge amount could freeze or crash the server.
* **"Sell everything" pays exactly what the confirmation showed.** If your inventory or the prices changed in the meantime, nothing is sold and you confirm again.
* **Menus react only to plain left/right clicks.** Double click, number keys, Q and the middle button are ignored.
* **Price 0 means "not for sale".** Such items are no longer taken for nothing by selling or by "Sell everything".
* The README no longer promises a specific "Unknown command" message for `/sa`: what a player sees is decided by the server.

## Upgrade notes

* Replace the jar and restart. Do not delete `config.yml`, `shop.yml` or the `lang` folder.
* New texts are added to `lang/uk.yml` and `lang/en.yml` automatically.
* Items with price 0 in `shop.yml` stop being sellable; set a price to enable them.
* No breaking changes.
