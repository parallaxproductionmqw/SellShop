# SellShop 1.4.1

## What's new since 1.4

* **Creative mode is admin-only.** Players in creative mode can no longer sell items. The new permission `sellshop.creative` is given to operators and to everyone with `sellshop.admin`.
* **Everything can be edited from the `/sa` panel now.**
  * **Prices:** buttons `-10 / -1 / -0.1` and `+0.1 / +1 / +10` right on the item screen (Shift = ×10), or type an exact value in chat.
  * **Items:** add by clicking an item in your inventory, from your hand, or by name; change the mode and bundle size; delete.
  * **Category settings:** title, icon, menu slot and currency.
  * **Settings:** the "Sell everything" slot and icon, main menu rows, the donate currency (on/off, name, payout command), the money name, the prefix, the menu titles, and any text of the language file by its key.
  * Values are typed in chat: your message is hidden from other players, and `cancel` aborts.
* **Categories are never lost.** If they do not fit, the main menu grows up to 6 rows and then gets pages. The admin category list has pages too.
* **Nothing is lost on stop.** The sales log and the counter are flushed on shutdown, the counter is saved every 5 seconds.
* **Safer donate payout.** The player can no longer get both the donate currency and the items back when the payout command returns "false". Payouts are whole numbers by default (`currencies.donate.whole-amounts`).
* **Safer `shop.yml`:** saved atomically, your comments and extra keys are kept. **A typo in the file can no longer erase your shop:** if it cannot be read, the previous data is kept, a copy is saved as `shop.yml.broken`, and nothing is written until you fix the file and run `/sa reload`.
* **Price 0 means "not for sale".** Such items are no longer taken for nothing by selling or by "Sell everything".
* **Taking from the counter is limited to 36 stacks at once** (`/sa take`, Shift+click). The rest stays in the counter.
* **Menus react only to plain left/right clicks.** Double click, number keys, Q and the middle button are ignored.
* **The menu sells what you saw.** If an admin changes prices while you look at a category, nothing is sold and the menu refreshes. "Sell everything" pays exactly what the confirmation showed: if something changed meanwhile, nothing is sold and you confirm again.
* Prices are limited to 1 000 000 000. Item icons hide attributes. The README no longer promises a specific "Unknown command" message for `/sa`: what a player sees is decided by the server. Smaller fixes are listed in `CHANGELOG.md`.

## Upgrade notes

* Replace the jar and restart. Do not delete `config.yml`, `shop.yml` or the `lang` folder.
* New texts are added to `lang/uk.yml` and `lang/en.yml` automatically; your edited texts are kept and `.bak` backups are created.
* The new option `currencies.donate.whole-amounts` is added to `config.yml` automatically.
* Operators can sell from creative mode as before. To let other people do it, give them `sellshop.creative`.
* Items with price 0 in `shop.yml` stop being sellable; set a price to enable them.
* No breaking changes.
